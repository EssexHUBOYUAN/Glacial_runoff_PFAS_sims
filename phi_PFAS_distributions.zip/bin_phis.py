# -*- coding: utf-8 -*-
"""
Created on Wed May 10 20:16:57 2023
This program aims to bin the phi_PFASs in loged form
for 100'000 sims (12'500 each area), has 500 bins
@author: Admin
"""
import csv
import numpy as np
import matplotlib.pyplot as plt


def readfile(filename):
    D_phi_pfas_sims = dict()
    D_index = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                HEAD = False
                for item in line:
                    L = item.split('^')
                    area = L[0]
                    try:
                        PFAS = L[1]
                    except IndexError:
                        PFAS = 'SumPFASs'
                    D_phi_pfas_sims[area, PFAS] = []
                    D_index[line.index(item)] = tuple( L )
            else:
                for i in range(len(line)):
                    try:
                        item = D_index[i]
                        D_phi_pfas_sims[item].append(np.log10(float(line[i])))
                    except KeyError:
                        D_phi_pfas_sims[item[0], 'SumPFASs'].append(np.log10(float(line[i])))
    return D_phi_pfas_sims

def bin_list(L, MIN, MAX, N_bins):
    L_bins = []
    L.sort()
    dx = (MAX - MIN)/N_bins
    left_bound = MIN
    right_bound = MIN + dx
    ind = 0
    for i in range(N_bins):
        count = 0
        while L[ind] >= left_bound and L[ind] < right_bound:
            if ind < len(L)-1:
                count = count + 1
                ind = ind + 1
            else:
                L_bins.append(count)
                count = 0
                break
        else:
            L_bins.append(count)
            left_bound = left_bound + dx
            right_bound = right_bound + dx
    return L_bins

def data2bins(D_phi_pfas_sims, N_bins):
    D_pfas_dist = dict()
    for item in D_phi_pfas_sims:
        #MIN = D_phi_pfas_sims[item][0]-0.00001
        #MAX = D_phi_pfas_sims[item][-1]+0.00001
        #print(MIN, MAX)
        #MIN = -5.2
        #MAX = 0
        MIN = -2.5
        MAX = 3.5
        #MIN = -2.9883
        #MAX = 2.4377
        D_pfas_dist[item] = [bin_list(D_phi_pfas_sims[item], MIN, MAX, N_bins), [(MAX - MIN)/N_bins*i +MIN for i in range(N_bins)]]
        #plt.plot( D_pfas_dist[item][1], D_pfas_dist[item][0] )
        #plt.title(item[0]+' '+item[1])
        #plt.show()
        #print(np.sum(np.array(D_pfas_dist[item][0] )))
    return D_pfas_dist

def save_bins(D_pfas_dist, filename):
    with open(filename+'.csv', mode='w', newline='') as file:
        data = csv.writer(file)
        headline = []
        arr = []
        for item in D_pfas_dist:
            headline.append(item[0]+'^'+item[1])
            arr.append(D_pfas_dist[item][0])
        data.writerow(headline)
        arr = np.transpose( np.array(arr) )
        print(np.shape(arr))
        for arline in arr:
            data.writerow([x for x in arline])
    return

def binning(filename2bined, filename_result, N_bins, path = ''):
    #filename2bined = 'phi_PFAAs'
    #filename_result = 'phi_PFAAs_bined 0530'
    filename2bined = path + filename2bined
    filename_result = path + filename_result
    D_phi_pfas_sims = readfile(filename2bined)
    D_pfas_dist = data2bins(D_phi_pfas_sims, N_bins)
    save_bins(D_pfas_dist, filename_result)
    return

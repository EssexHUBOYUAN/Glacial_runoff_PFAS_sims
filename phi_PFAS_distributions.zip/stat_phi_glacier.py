# -*- coding: utf-8 -*-
"""
Created on Sun Jun  4 12:23:09 2023
in this program, the plux (phi) is will have their statistical values.
1. read the file of phi
2.0 sum over the subregions
2.1 for each month do statistics and find percentiles, the get_percentile fuction would be in voked from the 'statistics' package
3. save file:
    first make dictionary in form of [region]: phi_dec, phi_jan, ... ,
    then save file
    
@author: Doc Who
"""

import csv
import random

'''_____________________________________________________________________________________________________________________________'''
'''read_file'''
def readfile(filename):
    D_all_phi_month = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                for i in range(len(line)):
                    if i >= 3:
                        try:
                            phi = float(line[i])
                            try:
                                D_all_phi_month[line[0], line[1], line[2], i-3].append( phi )
                                #[region, subregion, sampletype, month(0-11)] = [ phi ]
                            except KeyError:
                                D_all_phi_month[line[0], line[1], line[2], i-3] = [phi]
                        except ValueError:
                            pass
    return D_all_phi_month

'''combine_subrgions'''
def drop(L,item):
    ind = L.index(item)
    L.pop(ind)
    return L
def reshuff(L):
    a = len(L)
    L_ind = [i for i in range(a)]
    newlist = []
    while len(newlist) < a:
        ind = random.choice(L_ind)
        drop(L_ind, ind)
        newlist.append( L[ind] )
    return newlist

def sum_sub_phi(D_all_phi_month):
    D_region_phi_month=dict()
    D_med1 = dict()
    for region, subregion, sampletype, month in D_all_phi_month:
        # first merging subsample phis together, and then randomize the list of phis 
        try:
            D_med1[region, subregion, month] = D_med1[region, subregion, month] + D_all_phi_month[region, subregion, sampletype, month]
        except KeyError:
            D_med1[region, subregion, month] = D_all_phi_month[region, subregion, sampletype, month]
    for region, subregion, month in D_med1:
        D_med1[region, subregion, month] = reshuff( D_med1[region, subregion, month] )
        try:
            D_region_phi_month[ region, month ].append( D_med1[region, subregion, month] )
        except KeyError:
            D_region_phi_month[ region, month ] = D_med1[region, subregion, month]
    for item in D_region_phi_month:
        length = 0
        init = True
        for L in D_region_phi_month[item]:
            if len(L) > length:
                length = len(L)
                if not init:
                    print('non homogenous length')
                else:
                    init = False
            else:
                pass
        for L in D_region_phi_month[item]:
            while len(L) < length:
                new = random.choice(L)
                L.append(new)
                
                
    
            
    
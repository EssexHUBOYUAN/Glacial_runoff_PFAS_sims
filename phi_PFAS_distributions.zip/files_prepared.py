# -*- coding: utf-8 -*-
"""
Created on Thu Jul  6 21:28:54 2023

@author: Admin

this file aims to get percitipation file and PFAS_logkow_info file
1.1 read the 'AveTemp_raw_est' or 'percipitation_raw_est' file in csv,
1.2 read 'PFAS_conc_locs_data',
1.3 read 'Precipitation_data_2020'

2.0 for each year form a file in path 'F:/projects/zyq/globle warmming prediction/' with filename as year
* here only years in mutiple of 5 were needed

2.1 form percipiation file: 'Precipitation_data' Glacial Region| Month | Min | Max| Mean | Std |
    2.1.0 from 'Precipitation_data_2020' get mean value partition of each month. form the each region form the line as 1Darray
    2.1.1 normalize the flux based on mean value and sd simulated
    2.1.2 save the percipitation data file
    2.1.3 move the file into corresponding year file

2.2 form copy of 'PFAS_logkow_info' in each file

2.3 form AirTemp file while combined with 'PFAS_conc_locs_data':
    2.3.1 get dictionary of {GlacierArea : ClimateZone, with array[SummerTemp| SummerTemp_sd| AveTemp| AveTemp_sd], area }
    2.3.2 get dictionary of {GlacierArea : average AveTemp weighted by area; SD (n = 14) }
    2.3.3 beased on 'AveTemp_raw_est', get {GlacierArea : du_AveTemp; F }
    2.3.4 get dictionary of { (GlacierArea, ClimateZone) : array[SummerTemp| SummerTemp_sd| AveTemp| AveTemp_sd]_new by +du, times F }
    2.3.5 save the file into corresponding year file
    
"""
import os
import pandas as pd
import csv
import numpy as np
import shutil
'''
1.1 read the 'AveTemp_raw_est' or 'percipitation_raw_est' file in csv
'''
def read_estfile(filename):
    D_region = {'region1':'West Canada and USA', 'region2':'Arctic Canada', 'region3':'Greenland', 'region4':'Arctic Europe', 'region5':'North Asia', 'region6':'Central Europe', 'region7':'South and Central Asia','region8':'Antarctic and Subantarctic ice sheet'}
    D_est = dict()
    L_headline = []
    L_model = []
    L_allyear = []
    with open(filename, mode='r', encoding='UTF-8-sig') as file:
        firstline = True
        secondline = True
        data = csv.reader(file)
        for line in data:
            if firstline:
                firstline = False
                for i in range(len(line)):
                    if i >= 1:
                        s = line[i]
                        model, region = s.split('^')
                        L_headline.append([model,D_region[region]])
                    else:
                        L_headline.append(['corner'])
            elif secondline:
                secondline = False
            else:
                for i in range(len(line)):
                    if i >= 1:
                        try:
                            D_est[L_headline[i][0], L_headline[i][1], int(line[0])].append(float(line[i]))
                        except KeyError:
                            D_est[L_headline[i][0], L_headline[i][1], int(line[0])] = [float(line[i])]
                    else:
                        L_allyear.append(int(line[0]))
    for head in L_headline:
        model = head[0]
        if model not in L_model:
            L_model.append(head[0])
    L_model.pop(0)
    #D_est = { model, region, year: est_mean, est_sd }
    return D_est, L_model, L_allyear

'''
1.2 read 'PFAS_conc_locs_data'
'''
def read_PFAS_conc_locs_data(path, filename = 'PFAS_conc_locs_data'):
    L_wholefile = []
    D_airtemp = dict()
    fileinfold = path+filename+'.csv'
    with open( fileinfold, mode='r', encoding='UTF-8-sig' ) as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
                L_wholefile.append(line)
            else:
                L_wholefile.append(line)
                D_airtemp[line[0], line[1]] = [ [float(line[7]),float(line[8]),float(line[9]),float(line[10])], int(line[12]) ] #glacier zone, climate zone: T_summer, dT_sum, T_ave, dT_ave
    return L_wholefile, D_airtemp

'''
1.3 read 'Precipitation_data_2020'
'''
def read_precipitation(filename, path='G:/glacier flux simulation/'):
    '''
    filename = 'Precipitation_data_2020.csv'
    return
    {area : [[min, max, ave, std], , , of precipitation per month]  }
    '''
    D_precipitation = dict()
    with open(path + filename, mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                HEAD = False
            else:
                try:
                    D_precipitation[line[0]].append([float(line[2]), float(line[3]), float(line[4]), float(line[5])])
                except KeyError:
                    D_precipitation[line[0]] = [ [float(line[2]), float(line[3]), float(line[4]), float(line[5])] ]
    for area in D_precipitation:
        D_precipitation[area] = np.array(D_precipitation[area])
    return D_precipitation

'''
2.0 for each year form a file in path 'F:/projects/zyq/globle warmming prediction/' with filename as year
'''

def makefiles( path, years, modelnames):
    for year in years:
        try:
            os.mkdir(path + year)
        except FileExistsError:
            pass
        yearpath = path + year + '/'
        for model in modelnames:
            try:
                os.mkdir( yearpath + model )
            except FileExistsError:
                pass
    return
'''
2.1.0 from 'Precipitation_data_2020' get mean value partition of each month. form the each region form the line as 1Darray
'''
def percipiation_std(D_precipitation):
    D_annual_precip_std = dict()
    for area in D_precipitation:
        array = D_precipitation[area]
        annual_ave = 0
        annual_std = 0
        for i in range(12):
            annual_ave = annual_ave + array[i,2]
            if array[i,3] > annual_std:
                 annual_std = array[i,3]
            else:
                pass
        D_annual_precip_std[area] = [annual_ave, annual_std]
        print(annual_ave, annual_std)
    return D_annual_precip_std
'''
2.1.1 normalize the flux based on mean value and sd simulated
'''
def percipiation_mag(D_annual_precip_std, filename, D_est_percipitation, L_est_years, L_model):
    '''
    input:
        D_annual_precip_std = { region: [annual_ave, annual_std] }
        D_precipitation = { region : [[min, max, ave, sd], , , of precipitation per month] }
        D_est_percipitation = { model, region, year: est_mean, est_sd }
    return:
        D_prepared_precip = { region : [[min, max, ave, sd], , , of precipitation per month] }
    '''
    D_prepared_precip = dict()
    ind = 0
    for  model, region, year in D_est_percipitation:
        est_mean2020, sd_2020 = D_est_percipitation[ model, region, 2020 ]
        if year in L_est_years:
            est_mean, est_sd = D_est_percipitation[ model, region, year ]
            std_mean = D_annual_precip_std[region][0]
            du = (est_mean - est_mean2020)/12
            lamda = est_sd/sd_2020
            D_precipitation = read_precipitation(filename)
            array = D_precipitation[region]
            #print(du, lamda)
            #print(array)
            array[0:12,0] = (array[0:12,0]-array[0:12,2])*lamda + array[0:12,2]
            array[0:12,1] = (array[0:12,1]-array[0:12,2])*lamda + array[0:12,2]
            array[0:12,3] = array[0:12,3]*lamda
            array[0:12,0:3] = array[0:12,0:3]+du
            for i in range(12):
                if array[i,0] < 0:
                    array[i,0] = 0
                else:
                    pass
            D_prepared_precip[model, region, year] = array

        else:
            pass
        ind = ind +1

    return D_prepared_precip

'''
2.1.2 save the percipitation data file
2.1.3 move the file into corresponding year file
'''
def save_percipiation( D_prepared_precip, path, L_year, filename = 'Precipitation_data.csv', samplefile = 'Precipitation_data_2020.csv' ):
    L_org = []
    with open(path + samplefile, mode = 'r', encoding = 'UTF-8-sig' ) as file:
        org = csv.reader(file)
        Head = True
        for line in org:
            if Head:
                L_org.append(line)
                Head = False
            else:
                L_org.append( [line[i] for i in range(len(line)-4)]  )
    D_med = dict() # { year,model : { region: array(12,4) <- months X min  max  ave  sd } }
    for model, region, year in D_prepared_precip:
        if year in L_year:
            try:
                D_med[year, model][region] = D_prepared_precip[ model, region, year ]
            except KeyError:
                D_med[year, model] = dict()
                D_med[year, model][region] = D_prepared_precip[ model, region, year ]
        else:
            pass
    del(D_prepared_precip)
    for year, model in D_med:
        with open(path + str(year) + '/'+model +'/'+ filename, mode='w', newline = '') as newfile:
            data = csv.writer(newfile)
            Head = True
            for line in L_org:
                if Head:
                    data.writerow(line)
                    Head = False
                else:
                    region = line[0]
                    j = int(line[1])-1
                    info = [ item for item in D_med[year, model][region][j] ]
                    data.writerow(line+info)
    return
    
def main_get_percipitaion(path):
    L_years = [2015+i for i in range(86)]
    #L_years = [2020]
    D_precipitation = read_precipitation('Precipitation_data_2020.csv')
    D_est_percipitation, L_model, L_allyear = read_estfile(path + 'percipitation_raw_est.csv')
    makefiles(path, [ str(y) for y in L_years ], L_model)
    D_annual_precip_std = percipiation_std(D_precipitation)
    D_prepared_precip = percipiation_mag(D_annual_precip_std, 'Precipitation_data_2020.csv', D_est_percipitation, L_years, L_model)
    save_percipiation( D_prepared_precip, path, L_years )
    return

#main_get_percipitaion('G:/zyq/globle warmming prediction/')
'''
____________________________________________________________________________________________________________________________________________
2.2 form copy of 'PFAS_logkow_info' in each file
'''
def copy_logkowinfo(path, L_years, L_models, file = 'logKow.xlsx'):
    for year in L_years:
        for model in L_models:
            shutil.copy( path+file, path+str(year)+'/'+model+'/'+file)
    return
def main_getlogkows(path):
    D_est_percipitation, L_model, L_allyear = read_estfile(path + 'percipitation_raw_est.csv')
    copy_logkowinfo(path, [2015+i for i in range(86)], L_model)
    return
#main_getlogkows('G:/zyq/globle warmming prediction/')

'''
_______________________________________________________________________________________________________________________________________
2.3.1 get dictionary of {GlacierArea : ClimateZone, with array[SummerTemp| SummerTemp_sd| AveTemp| AveTemp_sd], area }
2.3.2 get dictionary of {GlacierArea : average AveTemp weighted by area; SD (n = 14) }
'''
def aveT_weighted(D_airtemp):
    '''
    D_airtemp = {GlacierArea, ClimateZone :[ [SummerTemp| SummerTemp_sd| AveTemp| AveTemp_sd], area ]}
    '''
    D_regionT = dict()
    for region, zone in D_airtemp:
        LT = D_airtemp[region, zone][0][2]
        A = D_airtemp[region, zone][1]
        try:
            D_regionT[region] = [  D_regionT[region][0] + LT**2, D_regionT[region][1] + LT, D_regionT[region][2] + 1]
        except KeyError:
            D_regionT[region] = [ LT**2, LT, 1]
    for region in D_regionT:
        SX2 , SX, N = D_regionT[region]
        D_regionT[region] = [SX/N , np.sqrt(SX2/N - SX**2/N**2)]
    return D_regionT

'''
2.3.3 beased on 'AveTemp_raw_est', get {GlacierArea : du_AveTemp; F = NONE }
'''
def calibrated_trend(D_est_T, D_regionT):
    #D_est_T = { model, region, year: est_mean, est_sd }
    #D_regionT = {region: est_mean_2020, est_sd_2020 }
    D_2020T = dict()
    #print(D_est_T)
    for model, region, year in D_est_T:
        if year == 2020:
            D_2020T[model, region] = D_est_T[ model, region, year ][0]
    #print(D_du)
    #for model, region, year in D_est_T:
    #    D_est_T[ model, region, year ][0] = D_est_T[ model, region, year ][0] + D_du[region]
    D_varTintime = dict()
    for model, region, year in D_est_T:
        D_varTintime[model, region, year] = D_est_T[ model, region, year ][0] - D_2020T[model, region]
        if abs(D_varTintime[model, region, year]) > 15:
            print(model, region, year, D_varTintime[model, region, year])
        
    return D_varTintime

'''
2.3.4 get dictionary of { (GlacierArea, ClimateZone) : array[SummerTemp| SummerTemp_sd| AveTemp| AveTemp_sd]_new by +du, times F }
2.3.5 save the file into corresponding year file
'''
def save_airTempTrends(D_varTintime, L_year, L_model, path, filename = 'PFAS_conc_locs_data'):
    for year in L_year:
        for model in L_model:
            L_wholefile, D_airtemp = read_PFAS_conc_locs_data(path, filename = 'PFAS_conc_locs_data')
            with open( path + str(year) + '/' + model + '/' + filename + '.csv' , mode='w', encoding='utf-8', newline='') as file:
                data = csv.writer(file)
                Head = True
                for line in L_wholefile:
                    if Head:
                        Head = False
                        data.writerow(line)
                    else:
                        region = line[0]
                        line[7] = float(line[7]) + D_varTintime[model, region, year]
                        line[9] = float(line[9]) + D_varTintime[model, region, year]
                        # rewrite line[6] i.e. dT_water
                        line[6] = float(line[6]) + D_varTintime[model, region, year]/4.816*1.005 #heat capacitys of water and air
                        data.writerow(line)
        #print(region, year, line[9])
    return

def main_airTemp(path = 'G:/zyq/globle warmming prediction/'):
    L_year = [2015+i for i in range(86)]
    #L_year = [2020]
    D_est_T, L_model, L_allyear = read_estfile(path + 'AveTemp_raw_est.csv')
    L_wholefile, D_airtemp = read_PFAS_conc_locs_data(path, filename = 'PFAS_conc_locs_data')
    D_regionT = aveT_weighted(D_airtemp)
    D_varTintime = calibrated_trend(D_est_T, D_regionT)
    save_airTempTrends(D_varTintime, L_year, L_model, path)
    return
main_airTemp(path = 'F:/zyq/globle warmming projection/')
main_getlogkows('F:/zyq/globle warmming projection/')
main_get_percipitaion('F:/zyq/globle warmming projection/')
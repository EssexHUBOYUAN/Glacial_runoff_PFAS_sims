# -*- coding: utf-8 -*-
"""
Created on Sat Apr 15 00:24:35 2023

@author: Doc Who
"""
'''
0.0 functions lay out (flux function)
0.1 dictionary of basic info (summer/winter month and spring/fall month) (f_snowice in different sample types)

1.1 read file get dict {area, subarea, sampletype : Tsummaer, dTsummaer, Tave, dTave} 
    read file get dict {area, subarea, sampletype : subarea_area}
1.2 read file get dict {area, subarea, sampletype : [[min, max, ave, std], , , of precipitation per month]  }

2.0 find N_sims for each {area, subarea, sampletype: N_sims }
2.1 get T per monthXsim, {area, subarea, sampletype : 2Darray[[T_Jan s] , [T_Feb s ] ,... ] }
2.2 get glacier_hight loss(cm) {area, subarea, sampletype :2Darray[[h_Jan s], [h_Feb s], ... ] }

3. save phi_glacier file

'''
import csv
import Kd_calculation as kdcalc
import numpy as np
import random

'''__________________________________________________________________________________________________________________________________________'''
'''0 functions and dictionary'''

def phi_glacier(area, f_snowice, T_air, percipitation):
    # result in m^3, i.e. tonne
    return max(0, area*netpercipitation(f_snowice, T_air, percipitation)*10**3)

def netpercipitation(f_snowice, T_air, percipitation):
    # in mm(1E-3)
    return f_snowice*max(T_air,0) + delta(T_air, 0)*percipitation - (- 0.69*T_air + 0.0096)*10

def delta(x,a):
    if x > a:
        return 1
    else:
        return 0
'''__________________________________________________________________________________________________________________________________________'''
'''1 read data'''
def get_T_air(filename):
    #read PFAS conc data
    '''
    D_all_data   { sample_index : [whole line]  }
    D_head_ind  {  file_index : head }
    
    return:
    D_T_air { area, subarea, sampletype: [Tsummaer, dTsummaer, Tave, dTave] }
    '''
    D_all_data, D_area_subsize, D_head_ind = kdcalc.read_PFAS_data(filename)
    del(D_area_subsize)
    D_T_air = dict()
    for line in D_all_data:
        head = tuple([ D_all_data[line][0], D_all_data[line][2], D_all_data[line][3] ])
        L_T_air = [ float(D_all_data[line][7]), float(D_all_data[line][8]), float(D_all_data[line][9]), float(D_all_data[line][10]) ]
        try:
            if D_T_air[head] == L_T_air:
                pass
            else:
                print('multi air temperatures in same sample type',D_T_air[head], L_T_air)
        except KeyError:
            D_T_air[head] = L_T_air
    return D_T_air

def get_areas(filename):
    #read PFAS conc data
    D_all_data, D_area_subsize, D_head_ind = kdcalc.read_PFAS_data(filename)
    del(D_all_data)
    del(D_head_ind)
    '''D_area_subsize: {area, subarea: [ subarea_name, area_size, subarea_size ]} '''
    D_subsize = dict()
    for area_name in D_area_subsize:
        for subarea in  D_area_subsize[area_name]:
            D_subsize[area_name, subarea[0]] = subarea[2]
    return D_subsize

def read_precipitation(filename):
    '''
    filename = 'Precipitation_data'
    return
    {area, subarea, sampletype : [[min, max, ave, std], , , of precipitation per month]  }
    '''
    D_precipitation = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                HEAD = False
            else:
                try:
                    D_precipitation[line[0]].append([float(line[2]), float(line[3]), float(line[4]), float(line[5])])
                except KeyError:
                    D_precipitation[line[0]] = [ [float(line[2]), float(line[3]), float(line[4]), float(line[5])] ]
    for area in D_precipitation:
        D_precipitation[area] = np.array(D_precipitation[area])
    return D_precipitation

'''__________________________________________________________________________________________________________________________________________'''
'''2. prepare sims'''
'''2.0 find N_sims for each {area, subarea, sampletype: N_sims }'''
# filename = 'PFAS_in_particle_conc.csv'
# file:  area| subare| sampletype| PFAS1_Jan | PFAS1_Feb | ... | PFAS1_Dec | PFAS2_Jan | ...'''
def get_N_sims_per_area(filename):
    D_Nsims = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                HEAD = False
            else:
                try:
                    D_Nsims[line[0],line[1],line[2]] = D_Nsims[line[0],line[1],line[2]]+1
                except KeyError:
                    D_Nsims[line[0],line[1],line[2]] = 1
    return D_Nsims

'''2.1 get T per monthXsim, {area, subarea, sampletype : 2Darray[[T_Jan s] , [T_Feb s ] ,... ] }'''
def add_dT_by_month(month, dTsummer, dTave, D_weatherstate):
    if D_weatherstate[month] == 'summer' or D_weatherstate[month] == 'winter':
        noise = random.normalvariate(0, dTsummer)
    else:
        noise = random.normalvariate(0, dTave)
    return noise

def get_prep_T_air(D_T_air, D_Nsims, D_weatherstate):
    '''
    D_T_air { area, subarea, sampletype: [Tsummer, dTsummer, Tave, dTave] }
    D_Nsims { area, subarea, sampletype: N_sims }
    return
    D_T_air_2Dprep {area, subarea, sampletype: [T_Jan, T_Feb, ..., T_Dex]}
    '''
    D_T_air_2Dprep = dict()
    for subareatype in D_T_air:
        N_sims = D_Nsims[subareatype]
        Tsummer, dTsummer, Tave, dTave = D_T_air[subareatype]
        arr_temp_monthXNsims = []
        for sim in range(N_sims):
            #print(Tave, (Tsummer-Tave))
            arr_temp = np.array( kdcalc.temp_sine_per_month(Tave,(Tsummer-Tave)) )
            for month in range(len(arr_temp)):
                arr_temp[month] = arr_temp[month]+add_dT_by_month(month, dTsummer, dTave, D_weatherstate)
            arr_temp_monthXNsims.append( arr_temp )
        arr_temp_monthXNsims = np.transpose( np.array(arr_temp_monthXNsims) )
        D_T_air_2Dprep[subareatype] = arr_temp_monthXNsims
    return D_T_air_2Dprep

'''2.2 get glacier_hight loss(cm) {area, subarea, sampletype :2Darray[[h_Jan s], [h_Feb s], ... ] }'''
def choose_bounded(MIN, MAX, ave, std, k=12):
    L_choosen = []
    for i in range(k):
        item = random.normalvariate(ave, std)
        while item > MAX or item < MIN:
            item = random.normalvariate(ave, std)
        else:
            pass
        L_choosen.append(item)
    return L_choosen

def get_glacier_hight(D_subareasize, D_precipitation, D_T_air_2Dprep, D_af_snowice_area, D_f_snowice):
    #print(D_subareasize)
    #print(D_precipitation)
    #print(D_T_air_2Dprep)
    #phi_glacier(month, areasize, f_snowice, T_air, percipitation)
    '''
    D_subareasize {area, subarea: subarea_area}
    D_precipitation {area, subarea, sampletype : [[min, max, ave, std], , , of precipitation per month]  }
    D_T_air_2Dprep {area, subarea, sampletype: [[T_Jan], [T_Feb], ..., [T_Dec]] }
    D_f_snowice {'Seawater':1, 'Glacial runoff':1, 'snow/ice':1}
    
    return
    D_phi_glacier
    '''
    D_phi_glacier = dict()
    for area, subarea, sampletype in D_T_air_2Dprep:
        f_snowice = D_f_snowice[sampletype]
        subarea_area = D_subareasize[area, subarea]
        af = D_af_snowice_area[area]
        Nmonth, Nsims = np.shape(D_T_air_2Dprep[area, subarea, sampletype])
        #print(Nmonth, Nsims)
        arr_phi_glacier = np.zeros((Nmonth, Nsims))
        for month in range(Nmonth):
            for sim in range(Nsims):
                MIN, MAX, ave, std = D_precipitation[area][month]
                precipitation_month = choose_bounded(MIN, MAX, ave, std, k=1)
                #print( subarea_area, D_T_air_2Dprep[area, subarea, sampletype][month,sim], precipitation_month[month] )
                arr_phi_glacier[month, sim] = af*phi_glacier(subarea_area, f_snowice, D_T_air_2Dprep[area, subarea, sampletype][month,sim], precipitation_month[0])
        D_phi_glacier[area, subarea, sampletype] = arr_phi_glacier
    return D_phi_glacier
'''__________________________________________________________________________________________________________________________________________'''
'''4.0 read phi glacier in a year over area file'''
def read_phi_glacier_calib(filename):
    D_phi_glacier_calib = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        for line in data:
            D_phi_glacier_calib[line[0]] = float(line[1])*1E9
    return D_phi_glacier_calib

'''4.1 get phi glacier in a year over area by averageing over each sampletype, and average over sample types, and lastly sum over subareas'''
def get_phi_glacier_area_year(D_phi_glacier):
    D_med = dict()
    D_med2 = dict()
    for area, subarea, sampletype in D_phi_glacier:
        arr_phi_glacier = D_phi_glacier[area, subarea, sampletype]
        N_month, N_sims = np.shape(arr_phi_glacier)
        phi_year_ave = np.sum(arr_phi_glacier, axis=1)/N_sims
        phi_year_ave = np.sum( phi_year_ave, axis=0 )
        D_med[area, subarea, sampletype] = phi_year_ave
    for area, subarea, sampletype in D_med:
        try:
            D_med2[area, subarea].append(D_med[area, subarea, sampletype])
        except KeyError:
            D_med2[area, subarea] = [ D_med[area, subarea, sampletype] ]
    del(D_med)
    D_phi_area_year = dict()
    for area, subarea in D_med2:
        a = 0
        for ai in D_med2[area, subarea]:
            a = a+ai
        try:
            D_phi_area_year[area] = D_phi_area_year[area] + a/len(D_med2[area, subarea])
        except KeyError:
            D_phi_area_year[area] = a/len(D_med2[area, subarea])
    del(D_med2)
    return D_phi_area_year

'''4.2 get af_icesnow'''
def get_af_icesnow(D_phi_glacier_calib, D_phi_area_year):
    D_af_icesnow = dict()
    for area in D_phi_area_year:
        phi_expected = D_phi_area_year[area]
        phi_measured = D_phi_glacier_calib[area]
        D_af_icesnow[area] = phi_measured/phi_expected
    print(D_af_icesnow)
    return D_af_icesnow
    
'''__________________________________________________________________________________________________________________________________________'''
'''3. save phi_glacier file'''
def save_phi_glacier(D_phi_glacier, filename):
    with open(filename+'.csv' ,mode='w', newline='') as file:
        data = csv.writer(file)
        headline = ['Area', 'Subarea', 'SampleType', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov' ]
        data.writerow(headline)
        for area, subarea, sampletype in D_phi_glacier:
            for line in np.transpose( D_phi_glacier[area, subarea, sampletype] ):
                data.writerow([area, subarea, sampletype] + list(line))
        return

'''__________________________________________________________________________________________________________________________________________'''
'''main'''
def phi_glacier_main(medtype, path = ''):
    D_weatherstate = {0:'winter', 1:'winter' ,2:'winter' ,3:'spring' ,4:'spring', 5:'spring' ,6:'summer', 7:'summer', 8:'summer', 9:'auttumn' ,10:'auttumn', 11:'auttumn' }
    D_f_snowice = {'seawater':4, 'Glacial runoff':1, 'snow/ice':2}
    chemlogkow_filename = path + 'PFAS_logkow_info'
    PFAS_filename = path + 'PFAS_conc_locs_data'
    Precipitation_filename = path + 'Precipitation_data'
    '''
    D_af_snowice_area = {'West Canada and USA': 0.5939, 'Arctic Canada': 2.9115*0.8313, 'Greenland': 3.4049, 
                         'Arctic Europe': 0.1614*1.01918, 'North Asia': 2.8070*0.9585, 'Central Europe': 2.0827*1.1408, 
                         'South and Central Asia': 0.7874, 'Antarctic and Subantarctic ice sheet': 0.003336*0.9459} #D_f_snowice = {'seawater':16, 'Glacial runoff':1, 'snow/ice':8}
    '''
    '''
    D_af_snowice_area = {'West Canada and USA': 0.5939*1.3256337821969812, 'Arctic Canada': 2.9115*0.8313*1.199650609750412, 'Greenland': 3.4049*1.2622426060936013, 
                         'Arctic Europe': 0.1614*1.01918*1.1772390571233355, 'North Asia': 2.8070*0.9585*1.5482395374145206, 'Central Europe': 2.0827*1.1408*1.3843142932844867, 
                         'South and Central Asia': 0.7874*1.3681328812154547, 'Antarctic and Subantarctic ice sheet': 0.003336*0.9459*1.5632303488707615}
    '''
    D_af_snowice_area = {'West Canada and USA': 0.65696, 'Arctic Canada': 2.72522, 'Greenland': 4.70465, 
                         'Arctic Europe': 0.20871*0.95071, 'North Asia':4.09962, 'Central Europe': 3.12841, 
                         'South and Central Asia':0.91507, 'Antarctic and Subantarctic ice sheet': 0.003*1.58107*0.989}
    
    if medtype == 'water':
        PFAS_sims_filename = path +  'PFAS_in_water_conc'
        phi_glacier_filename = path +  'phi_glacier_4water' #water flux
    else:
        PFAS_sims_filename = path + 'PFAS_in_particle_conc'
        phi_glacier_filename = path + 'phi_glacier_4particle' #particle flux
    
    D_T_air = get_T_air(PFAS_filename)
    D_subareasize = get_areas(PFAS_filename)
    D_precipitation = read_precipitation(Precipitation_filename)
    D_Nsims = get_N_sims_per_area(PFAS_sims_filename)
    
    D_T_air_2Dprep = get_prep_T_air(D_T_air, D_Nsims, D_weatherstate)
    D_phi_glacier = get_glacier_hight(D_subareasize, D_precipitation, D_T_air_2Dprep, D_af_snowice_area, D_f_snowice)
    
    save_phi_glacier(D_phi_glacier, phi_glacier_filename)
    return
    

def calibration_af(path = 'F:/zyq/globle warmming prediction/sims 1203/2020/SSP126/'):
    D_weatherstate = {0:'winter', 1:'winter' ,2:'winter' ,3:'spring' ,4:'spring', 5:'spring' ,6:'summer', 7:'summer', 8:'summer', 9:'auttumn' ,10:'auttumn', 11:'auttumn' }
    D_f_snowice = {'seawater':4, 'Glacial runoff':1, 'snow/ice':2}
    chemlogkow_filename = path + 'PFAS_logkow_info'
    PFAS_filename = path + 'PFAS_conc_locs_data'
    Precipitation_filename = path + 'Precipitation_data'
    '''
    D_af_snowice_area = {'West Canada and USA': 0.5939, 'Arctic Canada': 2.9115*0.8313, 'Greenland': 3.4049, 
                         'Arctic Europe': 0.1614*1.01918, 'North Asia': 2.8070*0.9585, 'Central Europe': 2.0827*1.1408, 
                         'South and Central Asia': 0.7874, 'Antarctic and Subantarctic ice sheet': 0.003336*0.9459} #D_f_snowice = {'seawater':16, 'Glacial runoff':1, 'snow/ice':8}
    '''
    '''
    D_af_snowice_area = {'West Canada and USA': 0.5939*1.3256337821969812, 'Arctic Canada': 2.9115*0.8313*1.199650609750412, 'Greenland': 3.4049*1.2622426060936013, 
                         'Arctic Europe': 0.1614*1.01918*1.1772390571233355, 'North Asia': 2.8070*0.9585*1.5482395374145206, 'Central Europe': 2.0827*1.1408*1.3843142932844867, 
                         'South and Central Asia': 0.7874*1.3681328812154547, 'Antarctic and Subantarctic ice sheet': 0.003336*0.9459*1.5632303488707615}
    '''
    D_af_snowice_area = {'West Canada and USA': 0.65696, 'Arctic Canada': 2.72522*1.03, 'Greenland': 4.70465*1.08, 
                         'Arctic Europe': 0.20871*0.95071, 'North Asia':4.09962, 'Central Europe': 3.12841, 
                         'South and Central Asia':0.91507, 'Antarctic and Subantarctic ice sheet': 0.003*1.58107*0.989}
    #PFAS_sims_filename = 'PFAS_in_water_conc_xgb'
    #phi_glacier_filename = 'phi_glacier_4water' #water flux
    PFAS_sims_filename = path + 'PFAS_in_particle_conc'
    phi_glacier_filename = path + 'phi_glacier_4water' #particle flux
    phi_glacier_cali_filename = path + 'phi_glacier_calibration'
    D_T_air = get_T_air(PFAS_filename)
    D_subareasize = get_areas(PFAS_filename)
    D_precipitation = read_precipitation(Precipitation_filename)
    D_Nsims = get_N_sims_per_area(PFAS_sims_filename)
    
    D_T_air_2Dprep = get_prep_T_air(D_T_air, D_Nsims, D_weatherstate)
    D_phi_glacier = get_glacier_hight(D_subareasize, D_precipitation, D_T_air_2Dprep, D_af_snowice_area, D_f_snowice)
    D_phi_area_year = get_phi_glacier_area_year(D_phi_glacier)
    D_phi_glacier_calib = read_phi_glacier_calib(phi_glacier_cali_filename)
    D_af_icesnow = get_af_icesnow(D_phi_glacier_calib, D_phi_area_year)
    return
#phi_glacier_main()
#calibration_af()
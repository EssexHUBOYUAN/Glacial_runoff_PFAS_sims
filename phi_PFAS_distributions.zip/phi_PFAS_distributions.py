# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 21:36:44 2023

@author: Doc Who

this file reads 'PFAS_in_particle_conc' and 'phi_glacier', then find the total 'phi_PFAS'

1.1 read PFAS_in_particle_conc, get dict { area, subarea, sampletype, PFAS : [ [Dec, Jan, Feb, ... Nov], [Dec, Jan, Feb, ... Nov], ... , ]_of conc } in 1E-21
1.2 phi_glacier, get dict { area, subarea, sampletype : [ [Dec, Jan, Feb, ... Nov], [Dec, Jan, Feb, ... Nov], ... , ]_of phi } in ton
1.3 for each area, get {area, subarea: sample types}

2.1.1 for each PFAS each subarea, sampletype, get { area, subarea, sampletype, PFAS: 2D[Dec, Jan, Feb, ... Nov]_of phi} in kg
#2.1.2 and { area, subarea, sampletype, PFAS: [sim1, sim2, sim3,...]_of phi of year}
2.2.1 for each subarea, get { area, subarea : 2D[Dec, Jan, Feb, ... Nov]_of phi total PFASs} in kg
#2.2.2 for each subarea, get { area, subarea : [sim1, sim2, sim3,...]_of phi of total PFASs of year}
2.3.1 for each area, randomly pick subareas, and sum, {area : 2D[Dec, Jan, Feb, ... Nov]_of phi total PFASs} in kg


3.0 save { area : [Dec, Jan, Feb, ... Nov]_of phi total PFASs + sum over year}
3.1 save 
"""
import csv
import numpy as np
import random

'''________________________________________________________________________________________________________________________________________________'''
'''1.1 read PFAS_in_particle_conc, get dict { area, subarea, sampletype, PFAS : [ [Dec, Jan, Feb, ... Nov], [Dec, Jan, Feb, ... Nov], ... , ]_of conc } in 1E-18'''
def getkey(Dict, value):
    KEY = 'value out of range error'
    for key in Dict:
        if value in Dict[key]:
            KEY =  key
        else:
            pass
    return KEY

def read_PFAS_conc_particle(filename):
    D_PFAS_conc = dict()
    D_med = dict()
    D_head_ind = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                for item in line:
                    if line.index(item) >= 3:
                        PFAS, str_month = item.split('^')
                        try:
                            D_head_ind[PFAS, int(str_month)].append(line.index(item))
                        except KeyError:
                            D_head_ind[PFAS, int(str_month)] =[line.index(item)]
                    else:
                        pass
                HEAD = False
            else:
                for line_ind in range(len(line)):
                    item = line[line_ind]
                    if line_ind >= 3:
                        PFAS, month = getkey(D_head_ind, line_ind)
                        try:
                            D_med[line[0], line[1], line[2], PFAS, month].append(float(line[line_ind]))
                        except KeyError:
                            if float(line[line_ind]) == float(line[line_ind]):
                                D_med[line[0], line[1], line[2], PFAS, month]= [float(line[line_ind])]
                            else:
                                pass
                    else:
                        pass
    del(D_head_ind)
    for area, subarea, sampletype, PFAS, month in D_med:
        try:
            D_PFAS_conc[area, subarea, sampletype, PFAS].append(D_med[area, subarea, sampletype, PFAS, month])
        except KeyError:
            D_PFAS_conc[area, subarea, sampletype, PFAS] = [ D_med[area, subarea, sampletype, PFAS, month] ]
    del(D_med)
    for PFAS_type in D_PFAS_conc:
        D_PFAS_conc[PFAS_type] = np.transpose( np.array(D_PFAS_conc[PFAS_type]) )
        #print('D_PFAS_conc[',PFAS_type,']: shape', np.shape(D_PFAS_conc[PFAS_type]))
    
    return D_PFAS_conc

'''1.2 phi_glacier, get dict { area, subarea, sampletype : [ [Dec, Jan, Feb, ... Nov], [Dec, Jan, Feb, ... Nov], ... , ]_of phi } in ton'''
'''1.3 for each area, get {area, subarea: sample types}'''
def read_phi_glacier(filename):
    D_phi_glacier = dict()
    D_area_sampletype = dict()
    with open(filename+'.csv', mode='r', encoding = 'UTF-8-sig') as file:
        data = csv.reader(file)
        HEAD = True
        for line in data:
            if HEAD:
                HEAD = False
            else:
                try:
                    D_phi_glacier[line[0],line[1],line[2]].append( [float( line[i+3] ) for i in range(len(line)-3) ] )
                except KeyError:
                    D_phi_glacier[line[0],line[1],line[2]] = [ [float( line[i+3] ) for i in range(len(line)-3)] ]
                try:
                    if line[2] in D_area_sampletype[line[0],line[1]]:
                        pass
                    else:
                        D_area_sampletype[line[0],line[1]].append( line[2] )
                except KeyError:
                    D_area_sampletype[line[0],line[1]] = [ line[2] ]
                    
    for sampletype in D_phi_glacier:
        D_phi_glacier[sampletype] = np.array(D_phi_glacier[sampletype])
        #print('D_phi_glacier[',sampletype,']: shape', np.shape(D_phi_glacier[sampletype]))
    return D_phi_glacier, D_area_sampletype

'''________________________________________________________________________________________________________________________________________________'''
'''2.1.1 get each phi_PFAS for each subarea, sampletype, get { area, subarea, sampletype, PFAS: 2Darray[sim1[Dec, Jan, Feb, ... Nov], sim2[Dec, Jan, Feb, ... Nov] _of phi} in kg'''
'''2.1.2 and { area, subarea, sampletype, PFAS: [sim1, sim2, sim3,...]_of phi of year}'''
def check_shape(Arr1, Arr2):
    a1, b1 = np.shape(Arr1)
    a2, b2 = np.shape(Arr2)
    if b1 == b2 and b1 == 12:
        pass
    else:
        print('error over months, N_month not 12')
        return False
    a = max(a1, a2)
    if a == a1 and a == a2:
        return True
    else:
        return False
    
def get_phi_pfas_subarea_sample(D_phi_glacier, D_PFAS_conc, mediantype):
    if mediantype == 'water':
        lo = 1E-12 #for water
    else:
        lo = 1E-12 #for particle
    D_sample_PFAS_phi = dict()
#    D_sample_PFAS_phi_year = dict()
    for area, subarea, sampletype, PFAS in D_PFAS_conc:
        arr_sample_phi = D_phi_glacier[area, subarea, sampletype]
        arr_PFAS_conc = D_PFAS_conc[area, subarea, sampletype, PFAS]
        if check_shape(arr_sample_phi, arr_PFAS_conc):
            arr_sample_PFAS_phi = arr_sample_phi*arr_PFAS_conc*lo
        else:
            print(area, subarea, sampletype, "Error: N_sims not matched")
        D_sample_PFAS_phi[area, subarea, sampletype, PFAS] = arr_sample_PFAS_phi
#        D_sample_PFAS_phi_year[area, subarea, sampletype, PFAS] = np.sum(arr_sample_PFAS_phi, axis=1)
    return D_sample_PFAS_phi
#    return D_sample_PFAS_phi, D_sample_PFAS_phi_year

'''2.2.1 for each subarea, randomly pick samples, get { area, subarea : 2D[Dec, Jan, Feb, ... Nov]_of phi total PFASs} in kg'''
def get_phi_pfas_subarea(D_sample_PFAS_phi, N_sims_area=100, mag=27):
    # input: D_sample_PFAS_phi : { area, subarea, sampletype, PFAS: 2Darray[sim1[Dec, Jan, Feb, ... Nov], sim2[Dec, Jan, Feb, ... Nov] _of phi} in kg
    D_med = dict() #{area, subarea,PFAS : [ 2Darr_sampletype1, 2Darr_sampletype2, 2Darr_sampletype3 ] }
    D_phi_pfas_subarea = dict()
    for area, subarea, sampletype, PFAS in D_sample_PFAS_phi:
        arr_phi_sample = D_sample_PFAS_phi[area, subarea, sampletype, PFAS]
        try:
            D_med[area, subarea,PFAS].append(arr_phi_sample)
        except KeyError:
            D_med[area, subarea,PFAS] = [arr_phi_sample]
    for area, subarea, PFAS in D_med:
        N_sample = len(D_med[area, subarea,PFAS])
        
        for i in range(N_sims_area):
            L_k = random.choices(np.arange(N_sample), k=N_sample*mag)
            arr_phi_subarea = np.zeros(12)
            for k in L_k:
                arr_phi_sample = D_med[area, subarea,PFAS][k]
                N_sims, N_month = np.shape( arr_phi_sample )
                j = random.choices(np.arange(N_sims))[0]
                arr_choice = np.array([phi for phi in arr_phi_sample[j]])
                arr_phi_subarea = arr_phi_subarea + arr_choice
            arr_phi_subarea = arr_phi_subarea/len(L_k)
            try:
                D_phi_pfas_subarea[area, subarea, PFAS].append(arr_phi_subarea)
            except KeyError:
                D_phi_pfas_subarea[area, subarea, PFAS] = [arr_phi_subarea]
    del(D_med)
    for area, subarea, PFAS in D_phi_pfas_subarea:
        D_phi_pfas_subarea[area, subarea, PFAS] = np.array(D_phi_pfas_subarea[area, subarea, PFAS])
    return D_phi_pfas_subarea

'''2.3.1 for each area, sum over subareas, {area : 2D Nsims X[Dec, Jan, Feb, ... Nov]_of phi total PFASs} in kg'''
def get_phi_pfas_area(D_phi_pfas_subarea):
    #input:  { area, subarea, PFAS : 2D(area_simsXmonth)[Dec, Jan, Feb, ... Nov]_of phi PFASs} in kg
    #return: { area, PFAS: 2D(area_simsXmonth)}
    D_phi_PFAS_area = dict()
    for area, subarea, PFAS in D_phi_pfas_subarea:
        arr_phi_subarea = D_phi_pfas_subarea[area, subarea, PFAS]
        try:
            D_phi_PFAS_area[area, PFAS].append(arr_phi_subarea)
        except KeyError:
            D_phi_PFAS_area[area, PFAS] = [arr_phi_subarea]
    for area_PFAS in D_phi_PFAS_area:
        N_sims, N_month = np.shape(D_phi_PFAS_area[area_PFAS][0])
        arr_area = np.zeros( (N_sims, N_month) )
        for arr in D_phi_PFAS_area[area_PFAS]:
            arr_area = arr_area + arr
        D_phi_PFAS_area[area_PFAS] = arr_area
        
    return D_phi_PFAS_area
def sum_month(D_phi_PFAS_area):
    # sum over month, get annual results {area, PFAS: [sim1_phi, sim2_phi, ... ]}
    # return: D_phi_PFAS_area_year
    for area,PFAS in D_phi_PFAS_area:
        D_phi_PFAS_area[area,PFAS] = np.sum(D_phi_PFAS_area[area,PFAS], axis=1)
    return D_phi_PFAS_area #D_phi_PFAS_area_year {area,PFAS: list of kg}

def sum_pfas(D_phi_PFAS_area_year):
    # input: {area, PFAS: sorted list of kg}
    # sum over PFAS, get phi_PFAAs: {area: [sim1_phi, sim2_phi, ... ]}
    D_phi_PFAAs = dict()
    for area, PFAS in D_phi_PFAS_area_year:
        try:
            newflux = D_phi_PFAS_area_year[area, PFAS]
            try:
                D_phi_PFAAs[area] = D_phi_PFAAs[area] + newflux
            except KeyError:
                D_phi_PFAAs[area] = D_phi_PFAS_area_year[area, PFAS]
        except KeyError:
            pass
    return D_phi_PFAAs

'''________________________________________________________________________________________________________________________________________________'''
'''3.0 save { area : [Dec, Jan, Feb, ... Nov]_of phi total PFASs + sum over year}'''
def mean(L):
    L.sort()
    ind = round(len(L)/2)
    return L[ind]
def save_mean_phi_pfas_area(D_phi_PFAS_area_year, filename):
    L_PFAS = []
    L_area = []
    for area, PFAS in D_phi_PFAS_area_year:
        if PFAS not in L_PFAS:
            L_PFAS.append(PFAS)
        else:
            pass
        if area not in L_area:
            L_area.append(area)
        else:
            pass
    print(L_area)
    print(L_PFAS)
    arr_means = np.zeros((len(L_area), len(L_PFAS)))
    for area, PFAS in D_phi_PFAS_area_year:
        i_area = L_area.index(area)
        j_PFAS = L_PFAS.index(PFAS)
        arr_means[i_area, j_PFAS] = mean( D_phi_PFAS_area_year[area, PFAS] )
        
    with open(filename+'.csv', mode='w', newline='') as file:
        data = csv.writer(file)
        data.writerow( ['area']+L_PFAS )
        for i in range(len(L_area)):
            line = [ L_area[i] ] + [pfas for pfas in arr_means[i]]
            data.writerow( line )
    return

def save_phi_pfas_area(D_phi_PFAS_area_year, filename):
    with open(filename+'.csv', mode='w', newline='') as file:
        data = csv.writer(file)
        headline = [item[0]+'^'+item[1] for item in D_phi_PFAS_area_year]
        l_depth = [len(D_phi_PFAS_area_year[item]) for item in D_phi_PFAS_area_year]
        depth = np.max(np.array( l_depth ))
        data.writerow(headline)
        for item in D_phi_PFAS_area_year:
            D_phi_PFAS_area_year[item].sort()
        for i in range(depth):
            line = []
            for item in D_phi_PFAS_area_year:
                try:
                    line.append( D_phi_PFAS_area_year[item][i] )
                except IndexError:
                    line.append( np.nan )
            data.writerow(line)
    return

def save_phi_PFAAs(D_phi_PFAAs, filename):
    with open(filename+'.csv', mode='w', newline='') as file:
        data = csv.writer(file)
        L = []
        headline = []
        for area in D_phi_PFAAs:
            headline.append(area)
            L_area = list(D_phi_PFAAs[area])
            L_area.sort(reverse = True)
            L.append( L_area )
        arr = np.transpose( np.array(L) )
        data.writerow(headline)
        for line in arr:
            data.writerow([value for value in line])
    return 
        
'''________________________________________________________________________________________________________________________________________________'''
'''main'''
def Phi_PFAS_sims(mediantype, N_sims_area=100, mag = 10, path=''):
    if mediantype == 'water':
        particle_conc_filename = path + 'PFAS_in_water_conc'
        phi_glacier_filename = path + 'phi_glacier_4water'
        phi_PFAAs_filename = path + 'phi_PFAAs_water'
        phi_mean_PFAS_filename = path + 'phi_means_areaXPFAS_water'
        phi_allpfas_filename = path + 'phi_all_areaXPFAS_water'
    else:
        particle_conc_filename = path + 'PFAS_in_particle_conc'
        phi_glacier_filename = path + 'phi_glacier_4particle'
        phi_PFAAs_filename = path + 'phi_PFAAs_particle'
        phi_mean_PFAS_filename = path + 'phi_means_areaXPFAS_particle'
        phi_allpfas_filename = path + 'phi_all_areaXPFAS_particle'

    D_PFAS_conc = read_PFAS_conc_particle(particle_conc_filename)
    D_phi_glacier, D_area_sampletype = read_phi_glacier(phi_glacier_filename)
    
    D_sample_PFAS_phi = get_phi_pfas_subarea_sample(D_phi_glacier, D_PFAS_conc, mediantype)
    D_phi_pfas_subarea = get_phi_pfas_subarea(D_sample_PFAS_phi, N_sims_area=N_sims_area, mag = mag)
    D_phi_PFAS_area = get_phi_pfas_area(D_phi_pfas_subarea)
    D_phi_PFAS_area_year = sum_month(D_phi_PFAS_area)
    D_phi_PFAAs = sum_pfas( D_phi_PFAS_area_year )
    save_phi_pfas_area(D_phi_PFAS_area_year, phi_allpfas_filename)
    
    save_phi_PFAAs(D_phi_PFAAs, phi_PFAAs_filename)
    #save_mean_phi_pfas_area(D_phi_PFAS_area_year, phi_mean_PFAS_filename)
    return

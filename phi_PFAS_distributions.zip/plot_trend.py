# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 17:41:45 2023
this file forms the fig of the 3 model trends by their 70% 50% 30% ( can be changed)
1.1 read across the file (+ path) and collect information from 'phi_PFAAs_particle', 'phi_PFAAs_water' by the asked percentile
1.2 read across the file (+ path) and collect information from 'phi_all_areaXPFAS_particle', 'phi_all_areaXPFAS_water' by the asked percentile

2.1 plot the curve for each item
@author: Admin
"""
import os
import shutil
import csv
import numpy as np
import matplotlib.pyplot as plt

D_model_color = {'SSP126':'steelblue', 'SSP245':'salmon', 'SSP585':'olive'}

"""__________________________read the phi file_____________________________"""
def read_phi(path, model, year, filename, L_p, N=2500):
    '''
    D_data = {year, model, region, p, title(particle/water), *not for PFAAs* PFAS : plux}
    '''
    D_data = dict()
    L_inds = [round(p*N) for p in L_p]
    if 'PFAAs' in filename:
        title = filename.split('_')[-1]
        filename = path + str(year) +'/'+ model +'/' + filename + '.csv'
        with open(filename, mode = 'r', encoding='UTF-8-sig') as file:
            data = csv.reader(file)
            i = 0
            for line in data:
                if i == 0:
                    L_region = line
                elif i in L_inds:
                    p_ind = L_inds.index(i)
                    p = L_p[p_ind]
                    for ind_item in range(len(line)):
                        region = L_region[ind_item]
                        D_data[year, model, region, p, title, 'PFAAs'] = float(line[ind_item])
                else:
                    pass
                i = i+1
    else:
        title = filename.split('_')[-1]
        filename = path + str(year) +'/'+ model +'/' + filename + '.csv'
        with open(filename, mode = 'r', encoding='UTF-8-sig') as file:
            data = csv.reader(file)
            i = 0
            for line in data:
                if i == 0:
                    L_region = line
                elif i in L_inds:
                    p_ind = L_inds.index(i)
                    p = L_p[p_ind]
                    for ind_item in range(len(line)):
                        region_PFAS = L_region[ind_item]
                        region, PFAS = region_PFAS.split('^')
                        D_data[year, model, region, p, title, PFAS] = float(line[ind_item])
                else:
                    pass
                i = i+1

    return D_data

def takesecond(l):
    return l[1]

def sort_data(D_data):
    '''
    D_plot_data = {model, region, p, title, PFAS : [ [phi, phi, ...], [year, year, ...]]}
    '''
    D_plot_data = dict()
    for year, model, region, p, title, PFAS in D_data:
        try:
            D_plot_data[model, region, p, title, PFAS].append([ D_data[year, model, region, p, title, PFAS], year ])
        except KeyError:
            D_plot_data[model, region, p, title, PFAS] = [[ D_data[year, model, region, p, title, PFAS], year ]]
    for model, region, p, title, PFAS in D_plot_data:
        D_plot_data[model, region, p, title, PFAS].sort(key=takesecond)
        D_plot_data[model, region, p, title, PFAS] = [[item[0] for item in D_plot_data[model, region, p, title, PFAS]], [item[1] for item in D_plot_data[model, region, p, title, PFAS]]]
    return D_plot_data

"""__________________________plot the curve_____________________________"""
def moving_average(l_a, r=5):
    arr = np.zeros((len(l_a)))
    for i in range(len(l_a)):
        if i < r/2:
            s = 0
            l_ind = []
            for k in range(1+min(2*i+1, 2*(len(l_a)-(i+1)))):
                try:
                    s = s+l_a[ k ]
                    l_ind.append(k)
                except IndexError:
                    pass
            arr[i]=s/(len(l_ind))
            #arr[i]=l_a[i]
        elif len(l_a)-(i+1) < r/2:
            s = 0
            l_ind = []
            for k in range(1+min(2*i+1, 2*(len(l_a)-(i+1))+1)):
                try:
                    s = s+l_a[ i-(len(l_a)-(i+1))+k-1 ]
                except IndexError:
                    pass
            arr[i]=s/(1+2*(len(l_a)-(i+1))+1)
            #arr[i]=l_a[i]
        else:
            s = 0
            l_ind = []
            for k in range(r):
                s = s+l_a[ int(i+1-r/2+k) ]
                l_ind.append(int(i+1-r/2+k))
            arr[i]=s/(len(l_ind))
    return arr

def ployfit(l_a, r1=3, r2=5, r3=7, r4=11):
    arr = moving_average(list(moving_average(list(moving_average(  list(moving_average(l_a, r1)) ,r2)),r3)), r4)
    return arr


def plot_data(D_plot_data, p_mid, p_bounds):
    '''
    for each PFAS paint a set of graphs, each contained 3 models with their bounds
    '''
    D_mid_data = dict()
    D_ub_data = dict()
    D_lb_data = dict()
    L_model = set()
    L_region = set()
    L_PFAS = set()
    for model, region, p, title, PFAS in D_plot_data:
        if p == p_mid:
            D_mid_data[model, region, title, PFAS] = D_plot_data[model, region, p, title, PFAS]
        elif p == p_bounds[0]:
            D_ub_data[model, region, title, PFAS] = D_plot_data[model, region, p, title, PFAS]
        elif p == p_bounds[1]:
            D_lb_data[model, region, title, PFAS] = D_plot_data[model, region, p, title, PFAS]
        else:
            pass
        L_model.add(model)
        L_region.add(region)
        L_PFAS.add(PFAS)
    L_model = list(L_model)
    L_region = list(L_region)
    L_PFAS = list(L_PFAS)
    #print(D_lb_data)
    for PFAS in L_PFAS:
        plt_loc = 241
        plt.figure(figsize=(22, 12), dpi=400)
        for region in L_region:
            try:
                plt.subplot(plt_loc)
                for model in L_model:
                    plt.plot(D_mid_data[model, region, title, PFAS][1], moving_average(D_mid_data[model, region, title, PFAS][0]), color=D_model_color[model], linewidth=0.4)
                    plt.plot(D_mid_data[model, region, title, PFAS][1], ployfit( D_mid_data[model, region, title, PFAS][0] ), color=D_model_color[model], linewidth=1.6)
                    plt.fill_between(D_ub_data[model, region, title, PFAS][1], moving_average(D_ub_data[model, region, title, PFAS][0])
                                     , moving_average(D_lb_data[model, region, title, PFAS][0]), color=D_model_color[model], alpha=0.13)
                    plt.title(title+' '+region+' '+PFAS)
                    plt.ylabel('flux kg')
                plt_loc = plt_loc+1
            except KeyError:
                plt_loc = plt_loc+1
        plt.show()
    return

'''__________________________save file__________________________'''
def save_plot_data(filename, path,L_year):
    return

"""__________________________flow_____________________________"""
def flowwork(filename, path,L_year, p_bounds = [0.975, 0.025], p_mid = 0.5):
    '''
    path : path of file (string)
    L_year : the year to plot (list of int)
    p_mid : 0.5 (float)
    p_bounds : list of up and lower bound (list of float)
    '''
    D_wholedata = {}
    L_p = p_bounds + [p_mid]
    for year in L_year:
        L_model = os.listdir(path+str(year))
        for model in L_model:
            D_data = read_phi(path, model, year, filename, L_p, N=2500)
            D_wholedata = {**D_wholedata, **D_data}
    D_plot_data = sort_data(D_wholedata)
    plot_data(D_plot_data, p_mid, p_bounds)
    return

def main():
    #filename = 'phi_all_areaXPFAS_particle'
    filename = 'phi_PFAAs_particle'
    path = 'G:/zyq/globle warmming prediction/1130 sims/'
    L_year = [i+2015 for i in range(86)]
    flowwork(filename, path, L_year)
    return

main()

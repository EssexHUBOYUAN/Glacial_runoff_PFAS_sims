# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 22:08:52 2023
this file establishe the flowwork for:
    A) the prepareations of getting xgboost modeling logkd
    B) from logkds get:
        1. PFAS_in_particle_conc_xgb/ PFAS_in_water_conc_xgb
        2. phi_glacier_4particle/ phi_glacier_4water
        3. phi_all_areaXPFAS_particle/ phi_all_areaXPFAS_water
        4. phi_PFAAs_particle/ phi_PFAAs_water
        5. Stats of PFAS_in_particle_conc_xgb/ Stats of PFAS_in_water_conc_xgb
        6. bined files
@author: Admin
"""
import sys
sys.path = list(set(sys.path))
sys.path.append('G:/glacier flux simulation/')
import os
import shutil
import Kd_calculation as gkd
import annual_glacier_flow_calculation as Pglacier
import phi_PFAS_distributions as Ppfas
import stat_concs as sconc
import bin_phis as binP


def flowwork_xyz(pathlist = [''], N_sims=100, mag_normal=10):
    for file in pathlist:
        gkd.main1('xyz_sims.csv', simulation_per_area = N_sims, mag_of_normal = mag_normal, path = file)
    return

def flowwork_predict(pathlist = [''], filename='xyz_sims.csv'):
    for file in pathlist:
        gkd.main3(path = file)
    return

def flowwork_phis(pathlist = [''], N_sims=100, mag_normal=10):
    for file in pathlist:
        gkd.main2('xyz_sims_logkd_xgb.csv', simulation_per_area = N_sims, mag_of_normal = mag_normal, path = file)
        
        Pglacier.phi_glacier_main('particle',path = file)
        Pglacier.phi_glacier_main('water',path = file)
        print('phi_glaciers file obtained')
        Ppfas.Phi_PFAS_sims('particle', N_sims_area=N_sims, mag = mag_normal, path=file)
        Ppfas.Phi_PFAS_sims('water', N_sims_area=N_sims, mag = mag_normal, path=file)
        print('phi_PFAS file obtained')
        
        sconc.stats_concs('PFAS_in_particle_conc', 'Stats of PFAS_in_particle_conc', path = file)
        sconc.stats_concs('PFAS_in_water_conc', 'Stats of PFAS_in_water_conc', path = file)
        print('statitics of conc file obtained')
        
        N_bins = 2500
        binP.binning('phi_all_areaXPFAS_particle', 'phi_all_areaXPFAS_particle_bined', N_bins, path = file)
        binP.binning('phi_all_areaXPFAS_water', 'phi_all_areaXPFAS_water_bined', N_bins, path = file)
        print('bined the sims PFASs')
        
        binP.binning('phi_PFAAs_particle', 'phi_PFAAs_particle_bined', N_bins, path = file)
        binP.binning('phi_PFAAs_water', 'phi_PFAAs_water_bined', N_bins, path = file)
        print('bined the sims Sum')
    return

N_sims = 2500
mag_normal = 100
path = 'F:/zyq/globle warmming projection/'
pathlist = []
for year in [i+2049 for i in range(9)]:
    for model in ['SSP126','SSP245','SSP585']:
        # check 2027 for console 10, 2043~ doing predict-est. 2049 canbe done, 2015+43 started
        # 2015, +43 done for +10s for phis
        pathlist.append( path + str(year) +'/' + model + '/')

#flowwork_xyz(pathlist, N_sims = N_sims, mag_normal = mag_normal)
#flowwork_predict(pathlist, filename='xyz_sims.csv')
flowwork_phis(pathlist, N_sims = N_sims, mag_normal = mag_normal)
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  3 18:20:29 2023
in this file the 'PFAS in water/particle conc.csv' would be found with their staticitcal values for each sample type of 8 regions:
    average, var(std), number of obs, 15, 2.5%, 10%, 50% ,90 %, 97.5%, 99%, min and max.
the statisitical value
@author: Doc Who
"""

import csv
import statistics
import numpy as np
from scipy import stats

'''_________________________________________________________________________________________________________'''
'''read files'''
def read_file(filename):
    D_8regions = dict()
    with open(filename+'.csv', mode='r', encoding='UTF-8-sig') as file:
        data=csv.reader(file)
        head = True
        for line in data:
            if head:
                headline = line
                head = False
            else:
                for i in range(len(line)):
                    if i > 2:
                        try:
                            conc = float(line[i])
                            if conc == conc:
                                try:
                                    D_8regions[line[0], line[1], line[2], headline[i]].append( conc )
                                except KeyError:
                                    D_8regions[line[0], line[1], line[2], headline[i]] = [ conc ]
                                    #[ region, subregion, sampletype, PFAStype ^ NO.month]
                            else:
                                pass
                        except ValueError:
                            conc = 'nan'
                        
                    else:
                        pass
    return D_8regions
'''_________________________________________________________________________________________________________'''
'''combine subregions and sampletypes
    to combine [ region, subregion, sampletype, PFAStype ^ NO.month] dict into [ region, PFAStype ^ NO.month ]'''
def conbine(D_8regions):
    D_region_conc_list = dict()
    for region, sub, sample, PFAS2M in D_8regions:
        try:
            D_region_conc_list[ region, PFAS2M ] = D_region_conc_list[ region, PFAS2M ] + D_8regions[region, sub, sample, PFAS2M]
        except KeyError:
            D_region_conc_list[ region, PFAS2M ] =  D_8regions[region, sub, sample, PFAS2M] 
    return D_region_conc_list
'''do statisitcs'''
def get_stat_for_region(D_lists, l_percentile=[1, 2.5, 10, 50, 90, 97.5, 99]):
    D_stats = dict()
    for l in D_lists:
        nobs, minmax, mean, var, skew, kurtosis = stats.describe(D_lists[l])
        MIN, MAX = minmax
        std = np.sqrt( var )
        L_pctvalue = get_percetiles( D_lists[l], l_percentile )
        D_stats[ l ] = [ nobs, MIN, MAX, mean, std ] + L_pctvalue
    return D_stats
        
'''_________________________________________________________________________________________________________'''
'''compute percentile values for list L'''      
def get_percetiles( L, l_percentile ):
    arr = np.array(l_percentile)
    if 100 in l_percentile:
        ind_max = l_percentile.index(100)
        arr[ind_max] = -1*100*len(L)
    else:
        pass
    L.sort()
    l_index = []
    for p in arr:
        l_index.append( int(p/100*len(L)) )
    L_values = []
    for i in l_index:
        L_values.append( L[i] )
    return L_values
'''_________________________________________________________________________________________________________'''
'''save file in form |region|PFAS|statistical value type| month number 0| 1 | 2 |...| 11 |
   D_stats_list = region, PFAS2M : nobs, MIN, MAX, mean, std  + L_pctvalue[ 1, 2.5, 10, 50, 90, 97.5, 99 ]
'''
def takesecond(l):
    return l[1]
def save_file(D_stats_list, filename, l_percentile=[1, 2.5, 10, 50, 90, 97.5, 99]):
    D_med = dict()
    for region, PFAS2M in D_stats_list:
        L_stat = D_stats_list[ region, PFAS2M  ]
        PFAS, month = PFAS2M.split('^')
        month = int(month)
        try:
            D_med[region, PFAS, 'N'].append( [L_stat[0], month] )
            D_med[region, PFAS, 'min'].append( [L_stat[1], month] )
            D_med[region, PFAS, 'max'].append( [L_stat[2], month] )
            D_med[region, PFAS, 'average'].append( [L_stat[3], month] )
            D_med[region, PFAS, 'sd'].append( [L_stat[4], month] )
            for ind_p in range(len(l_percentile)):
                p = l_percentile[ind_p]
                i = ind_p + 5
                s = str(p) + ' percent'
                D_med[region, PFAS, s].append( [L_stat[i], month] )
        except KeyError:
            D_med[region, PFAS, 'N']=[ [L_stat[0], month] ]
            D_med[region, PFAS, 'min']=[ [L_stat[1], month] ]
            D_med[region, PFAS, 'max']=[ [L_stat[2], month] ]
            D_med[region, PFAS, 'average']=[ [L_stat[3], month] ]
            D_med[region, PFAS, 'sd']=[ [L_stat[4], month] ]
            for ind_p in range(len(l_percentile)):
                p = l_percentile[ind_p]
                i = ind_p + 5
                s = str(p) + ' percent'
                D_med[region, PFAS, s]=[ [L_stat[i], month] ]
    del(D_stats_list)
    for item in D_med:
        L_month = [ conc[1] for conc in D_med[item]  ]
        #print(L_month)
        D_med[item].sort( key=takesecond )
        D_med[item] = [ conc[0] for conc in D_med[item]  ]
    
    with open(filename+'.csv', mode = 'w', newline='') as file:
        data = csv.writer(file)
        headline = ['region', 'PFAS','statistical value type', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov']
        data.writerow(headline)
        for region, PFAS, stat in D_med:
            L = D_med[region, PFAS, stat]
            line = [region, PFAS, stat ] + L
            data.writerow(line)
    return
'''_________________________________________________________________________________________________________'''
'''main'''
def stats_concs(rawfile, resultfile, path = ''):
    rawfile = path + rawfile
    resultfile = path + resultfile
    print(rawfile, resultfile)
    l_percentile=[1, 2.5, 10, 50, 90, 97.5, 99]
    
    D_8regions = read_file(filename = rawfile)
    D_region_conc_list = conbine(D_8regions)
    del(D_8regions)
    D_stats_list = get_stat_for_region(D_region_conc_list, l_percentile=l_percentile)
    del(D_region_conc_list)
    save_file(D_stats_list, resultfile, l_percentile=l_percentile )
    return

#resultfile = 'Stats of PFAS_in_water_conc'
#rawfile = 'PFAS_in_water_conc'    
#stats_concs(rawfile, resultfile)
            
            
                        

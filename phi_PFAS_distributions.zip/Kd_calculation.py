# -*- coding: utf-8 -*-
"""
Created on Mon Apr  3 12:40:45 2023
this prpgram aims to provide Kds for later simulations
0.  each count representation (X10? X50? X100? ...) \\
    each measured PFAS has number of simulations =10000 for each area

1. get functions, R2, and total sd_log(Kd) for Kd calculation

2. read through file for PFAS and its logKow, get dictionary { PFAS: logKow }

3.0 read through file get dictionary of 8 glaciers sperate subareas(zone): {area_name: subarea_name, area_size, subarea_size}
3.1.0 get dictionary for each { subarea, sample type: Sum_counts, number of simulations }
3.2.1 get dictionary for each { subarea, sample type: [T_water,sd] , array[POC], list[PFASs types X counts] }
3.2.2 get dictionary for each { subarea, sample type: list_T_water sine paras/or norm?/constant?, POC Normal curvefit paras }                          
3.2.3 get dictionary for each { subarea, sample type, PFAS: [T_water_permonth], [POC permonth], logKow}

4. get dictionary for each { subarea, sample type, PFAS: [Kd_Jan_set],[Kd_Feb_set], etc. } #leqLOD is Ture if < sign is found 
* optional 4.1 gwt dictionary { subarea, sample type, PFAS: [Kd+sd_Jan_set],[Kd+sd_Feb_set], etc. }
        first get sd of each set, and mutiply an constant s.t. the error can is proportional to the 1-R , them update dictionary by adding the error

5.1 get dictionary for conc_in_particleform { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc] }
5.2 get dictionary for conc_in_waterform { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc] }

6 save dictionary into file:  area| subare| sampletype| PFAS1_Jan | PFAS1_Feb | ... | PFAS1_Dec | PFAS2_Jan | ...

7. main
@author: Admin
"""

import numpy as np
import csv
import random
from scipy import stats
import xgboost as xgb
import pandas as pd

#sd_log_kd_tbt = 0.69 # basd on data from tibet plateau
#R2_logkd = 0.570219974142089
#sd_logkd = 1.023146449 # based on data from all 8 regions
#err_logkd = np.sqrt(1-R2_logkd)*sd_log_kd_tbt
#resid_logkd = np.sqrt(1-R2_logkd)*sd_logkd
#params_logkd = [0.0596, 0.8832, -1.7865, 15.9968, -1.6055, 12.9947, -0.6659, 0.6274, 2.0758, 3.4879, 0.7674]

chemlogkow_filename = 'PFAS_logkow_info'
PFAS_filename = 'PFAS_conc_locs_data'
simulation_per_area = 100
mag_of_normal = 10
D_SS = {'West Canada and USA':[182.225, 156.144978705689], 'Arctic Canada': [96.5714285714286,68.3412804404841], 'Greenland':[881.180681818182,1456.65840998389], 'Arctic Europe':[91.2771929824561, 135.722388251984],'North Asia':[91.2771929824561, 135.722388251984], 'Central Europe':[355.5, 158.511566349799], 'South and Central Asia':[485.792857142857, 348.35338296105], 'Antarctic and Subantarctic ice sheet':[72.555, 106.902201840436]}
D_logSS = {'West Canada and USA':[1.959833307, 0.670021258917696], 'Arctic Canada': [1.91005449514286,0.249937708818148], 'Greenland':[2.48036737303977,0.851292712912363], 'Arctic Europe':[1.45866884542105, 0.797334354872893],'North Asia':[1.45866884542105, 0.797334354872893], 'Central Europe':[2.49593689983333, 0.258785008819775], 'South and Central Asia':[2.59879782971429, 0.28688964499567], 'Antarctic and Subantarctic ice sheet':[1.48529546283333, 0.575151204423112]}
#SS in mg/kg; conc_water in pg/kg
'''
def error_logkd(sd = err_logkd):
    return random.normalvariate(sd, 0)

def logKd(lx,a,b,c,d,e,f,a1,b1,c1,d1,l):
    x,y,z = lx # x = Twater; y = logkow; z = log(TOC)
    TOC_KOW = Model_linear(lx,a1,b1,c1,d1)
    TEMP_KOW = Model_london(lx,a,b,c,d,e,f)
    return (1-l)*TOC_KOW + l*TEMP_KOW + error_logkd()

def Model_london(lx,a,b,c,d,e,f):
    x,y,z = lx
    lam = StepEXP(y,e,f)  # TOC is not considered yet
    logkd = lam*parab(x-3, a, b) + (1-lam)*linear(x-4, c, d)
    return logkd

def Model_linear(lx,a,b,c,d):
    x,y,z = lx
    logkd = a*y*z+b*y+c*z+d
    #-0.218, 0.231, 1.4529, 1.7958
    return logkd

def linear(x,a,b):
    return a*x+b

def parab(x,a,b):
    # a simplified version of parabla
    return a*x**2 + b
'''
def StepEXP(x,a,b):
    return np.exp((x-b)/a)/(1+np.exp((x-b)/a))

def temp_sine_per_month(tave, dt):
    l = [dt*np.sin((t-4)/12*2*np.pi) + tave for t in range(12)]
    return l
    

"""_____________________________________________________________________________________________________________________"""
'''2. read through file for PFAS and its logKow, get dictionary { PFAS: logKow }'''
def read_logkow(filename):
    df = pd.read_excel(filename)
    D_chemkow = dict()
    for i in range(len(df['chem'])):
        D_chemkow[df['chem'][i]] = [ float(df['logkow'][i]), int(df['PFCA or PFSA'][i])  ]
    return D_chemkow

"""_____________________________________________________________________________________________________________________"""
'''
3.0 read through file get dictionary of 8 glaciers sperate subareas(zone): {area_name: subarea_name, area_size, subarea_size}
3.1.0 get dictionary for each { subarea, sample type: Sum_counts, number of simulations }
3.2.1 get dictionary for each { subarea, sample type: [T_water,sd] , array[POC], list[PFASs types X counts] }
3.2.2 get dictionary for each { subarea, sample type: list_T_water sine paras/or norm?/constant?, POC Normal curvefit paras }                          
3.2.3 get dictionary for each { subarea, sample type, PFAS: [T_water_permonth], [POC permonth], logKow}
'''
#filename = 'PFAS_conc_locs_data'
def read_PFAS_data(filename):
    ''' provide 
    D_all_data   { sample_index : [whole line]  }
    D_area_subsize { area_name: [ subarea_name, subarea_size, area_size]  }
    D_head_ind  {  file_index : head }
    '''
    D_head_ind = dict()
    D_area_subsize = dict()
    D_all_data = dict()
    with open(filename+'.csv', mode = 'r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        head = True
        sample_ind = 0
        for line in data:
            if head:
                for item in line:
                    D_head_ind[line.index(item)] = item # raw data
                head = False
            else:
                D_all_data[sample_ind] = line
                sample_ind = sample_ind+1
                area = line[0].strip()
                subarea_name, subarea_size = [line[2],float(line[12])]
                try:
                    D_area_subsize[area].add(tuple([subarea_name, subarea_size]))
                except KeyError:
                    D_area_subsize[area] = set()
                    D_area_subsize[area].add(tuple([subarea_name, subarea_size])) #area_name: { [subarea_name, subarea_size] }
        for area in D_area_subsize:
            Sum_area = 0
            for subarea in D_area_subsize[area]:
                Sum_area = Sum_area + subarea[1]
            D_area_subsize[area] = [ list(subarea)+[Sum_area] for subarea in D_area_subsize[area] ]
    return D_all_data, D_area_subsize, D_head_ind

def get_dict_sims(D_all_data, D_area_subsize, N = 100):
    '''provide
    D_sims_weights { area, subarea, sampletype : subarea_counts, sampletype_counts, subarea_sims}
    '''
    D_sims_weights = dict()
    
    D_med_trunk = dict() #{ area, subarea: subarea_counts, sims_subarea }
    for area in D_area_subsize:
        for l_subarea in D_area_subsize[area]:
            D_med_trunk[area, l_subarea[0]] = [0,round(N*l_subarea[1]/l_subarea[2])]
    
    D_med_leaf = dict() # { area, subarea, sampletype: counts_sub_sampletype }
    
    for line_ind in D_all_data:
        line = D_all_data[line_ind]
        area, subarea, sampletype, counts = tuple( [ line[0], line[2], line[3], float(line[4]) ] )
        try:
            D_med_leaf[area, subarea, sampletype] = D_med_leaf[area, subarea, sampletype] + counts
        except KeyError:
            D_med_leaf[area, subarea, sampletype] = counts
        D_med_trunk[area, subarea] = [ D_med_trunk[area, subarea][0] + counts, D_med_trunk[area, subarea][1] ]
    
    for area, subarea, sampletype in D_med_leaf:
        D_sims_weights[area, subarea, sampletype] = [ D_med_trunk[area, subarea][0], D_med_leaf[area, subarea, sampletype], D_med_trunk[area, subarea][1] ]
    del(D_med_trunk)
    del(D_med_leaf)
    return D_sims_weights

def get_dict_raw_xyz(D_all_data, mag = 5):
    '''provide
    D_raw_xyz {  area, subarea, sampletype: [T_water,sd] , [POCs], list[PFASs conc X counts]  }
    list[PFASs types X counts]: <10 --> has 'mag' numbers of prepared samples; under normal distribution but >0; 
    
    '''
    D_raw_xyz = dict()
    for line_ind in D_all_data:
        line = D_all_data[line_ind]
        area, subarea, sampletype, counts, T, dT, POC, l_pfas_conc = tuple( [ line[0], line[2], line[3], int(line[4]), float(line[5]), float(line[6]), float(line[11]), [line[ind+13] for ind in range(len(line)-13)] ] )
        arr_reshaped10 = np.zeros((mag*counts,13))
        for i in range(len(l_pfas_conc)):
            conc = l_pfas_conc[i]
            if conc == '':
                for j in range(mag*counts):
                    arr_reshaped10[j,i] = np.nan
            else:
                try:
                    conc = float(conc)
                    for j in range(mag*counts):
                        arr_reshaped10[j,i] = conc
                except ValueError:
                    conc = float(conc.strip('<'))
                    mu = conc/2
                    sd = conc/3
                    for j in range(mag*counts):
                        c = 0
                        while c <= 0:
                            c = random.normalvariate(mu, sd)
                        arr_reshaped10[j,i] = c
        l_reshaped10 = np.transpose( arr_reshaped10 ) #each row is a list(len = sampletype_counts X mag) of conc for given PFAS type
        try:
            D_raw_xyz[area, subarea, sampletype][0].add(tuple([T,dT]))
            D_raw_xyz[area, subarea, sampletype][1].append(POC)
            D_raw_xyz[area, subarea, sampletype] = [D_raw_xyz[area, subarea, sampletype][0], D_raw_xyz[area, subarea, sampletype][1], np.concatenate([D_raw_xyz[area, subarea, sampletype][2],l_reshaped10], axis=1) ]
        except KeyError:
            D_raw_xyz[area, subarea, sampletype] = [set(), [POC], l_reshaped10  ]
            D_raw_xyz[area, subarea, sampletype][0].add(tuple([T,dT]))
            
    return D_raw_xyz
            
def test_notall_nan(a):
    A = False
    for x in a:
        if x == x:
            A = True
            break
        else:
            pass
    return A

def get_distruibution(D_raw_xyz):
    ''' 
    from {  area, subarea, sampletype: [T_water,sd] , [POC], list[PFASs types X counts]  }
    generate {  area, subarea, sampletype: array[T water per month], tuple(log POC normal), PFAS exists list[True/False]  }
    '''
    D_dis_params = dict()
    for sampletype in D_raw_xyz:
        if len(D_raw_xyz[sampletype][0]) == 1:
            LTdT = list(D_raw_xyz[sampletype][0])
        else:
            print('warnning: several Temperature measures in one area')
        T, dT = LTdT[0]
        d = np.sqrt( np.log(1+dT/(T**2)))
        u = np.log(T)-d**2/2
        l_logTwater = temp_sine_per_month(u, d)
        l_Twater = [np.exp(lt) for lt in l_logTwater]    
        arr_poc = np.array([ np.log10(poc) for poc in D_raw_xyz[sampletype][1] ])
        N, minmax, mu, var, skew, kurtosis = stats.describe(arr_poc)
        if N > 1:
            std = np.sqrt(var)
        else:
            std = 0
            
        L_PFAS_exist = []
        for arr_pfas in D_raw_xyz[sampletype][2]:
            L_PFAS_exist.append( test_notall_nan(arr_pfas) )
        #print(L_PFAS_exist)
        D_dis_params[sampletype] = [l_Twater, [mu,std], L_PFAS_exist]
    return D_dis_params

def get_envi_samples(D_distribution_params, D_sims_weights):
    '''
    Parameters
    ----------
    D_distribution_params : {  area, subarea, sampletype: array[T water per month], tuple(log POC normal mu, std)  }
    D_sims_weights : { area, subarea, sampletype : subarea_counts, sampletype_counts, subarea_sims}
    mag : int, optional The default is 5.

    Returns
    -------
    D_sims_envi : {  area, subarea, sampletype: No_sims, 2Darray[[T Jan, T Jan, ... ], [J Feb, T Feb, ...], ... [T Dec, T Dec, ... ]],  2Darray[[randoms by (mu, sd) ]]  }
    '''
    D_sims_envi = dict()
    for subarea in D_distribution_params:
        subarea_counts, sampletype_counts, subarea_sims = D_sims_weights[subarea]
        samplesims = round(subarea_sims*sampletype_counts/subarea_counts)
        # prepare samplesims many envi lists

        arr2D_Twater = np.transpose( np.array( [D_distribution_params[subarea][0] for i in range(samplesims)] ) )
        #prepare T water for each month
        
        mu, std = D_distribution_params[subarea][1]
        arr2D_poc = []
        for i in range(samplesims):
            L_poc = []
            for j in range(12):
                L_poc.append(random.normalvariate(mu, std))
            arr2D_poc.append(L_poc)
        arr2D_poc = np.transpose( np.array(arr2D_poc) )
        # prepare poc for each month
        
        D_sims_envi[subarea] = [samplesims, arr2D_Twater, arr2D_poc]
    return D_sims_envi

def get_xyz(D_sims_envi, D_dis_params, D_head_ind, D_chemkow):
    '''
    3.2.3 
    input:
        D_dis_params : {  area, subarea, sampletype: array[T water per month], tuple(log POC normal), PFAS exists list[True/False]  }
        D_sims_envi : { area, subarea, sampletype : [samplesims, arr2D_Twater, arr2D_poc] }
    output:
        D_xyz_monthXPFAS = { area, subarea, sample type, PFAS: 2Darray[T_water_permonth], 2Darray[POC permonth], 2Darray[logKow]}
    '''
    D_xyz_monthXPFAS = dict()
    for subarea in D_dis_params:
        for ind in range(len(D_dis_params[subarea][2])):
            PFAS_here = D_dis_params[subarea][2][ind]
            if PFAS_here:
                PFAS_name = D_head_ind[ind+13]
                logkow = D_chemkow[PFAS_name][0]
                CorS = D_chemkow[PFAS_name][1]
                D_xyz_monthXPFAS[subarea[0],subarea[1],subarea[2],PFAS_name] = [ D_sims_envi[subarea][1], D_sims_envi[subarea][2],
                                                                                np.ones((12,D_sims_envi[subarea][0]))*logkow, np.ones((12,D_sims_envi[subarea][0]))*CorS ]
            else:
                pass
    return D_xyz_monthXPFAS


"""_____________________________________________________________________________________________________________________"""
'''4. get dictionary for each { subarea, sample type, PFAS: [Kd_Jan_set],[Kd_Feb_set], etc. } #leqLOD is Ture if < sign is found '''
def save_D_xyz_monthXPFAS(D_xyz_monthXPFAS, filename):
    '''
    Parameters
    ----------
    D_xyz_monthXPFAS : dict
        { area, subarea, sample type, PFAS: 2Darray[T_water_permonth], 2Darray[POC permonth], 2Darray[logKow]}
    filename: str
        | area, subarea, sample type, PFAS|i, j|predicted values|
    
    '''
    with open(filename, mode='w', newline='') as file:
        data = csv.writer(file)
        headline = ['area', 'subarea', 'sampletype', 'PFAS','i','j','Temp', 'logkow', 'region', 'logTOC', 'PFCA or PFSA']
        data.writerow(headline)
        for sampletype_PFAS in D_xyz_monthXPFAS:
            area, subarea, sample, PFAS = sampletype_PFAS
            u,v = np.shape(D_xyz_monthXPFAS[sampletype_PFAS][0])
            for i in range(u):
                for j in range(v):
                    # lx = [ TempWater, logkow, logPOC ]
                    if sample == 'seawater':
                        region = 1
                    else:
                        region = 1
                    lx = [ i, j, D_xyz_monthXPFAS[sampletype_PFAS][0][i,j], D_xyz_monthXPFAS[sampletype_PFAS][2][i,j],
                          region, D_xyz_monthXPFAS[sampletype_PFAS][1][i,j], D_xyz_monthXPFAS[sampletype_PFAS][3][i,j]]
                    line = [area, subarea, sample, PFAS ] + lx
                    data.writerow(line)
    return
        
def get_kd_by_xyz(filename):
    '''
    Parameters
    ----------
    filename: str
        | area, subarea, sample type, PFAS|i, j|predicted values|
    Returns
    -------
    D_monthXkd_PFAS : dict
        { area, subarea, sample type, PFAS: 2Darray[logkd]}.
    '''
    D_monthXkd_PFAS_shape = dict()
    D_monthXkd_PFAS = dict()
    with open(filename, mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        Head = True
        for line in data:
            if Head:
                Head = False
            else:
                index, area, subarea, sampletype, PFAS, i, j, pred = line
                i = int(i)
                j = int(j)
                pred = float(pred)
                try:
                    if i >= D_monthXkd_PFAS_shape[area, subarea, sampletype, PFAS][0] and j >= D_monthXkd_PFAS_shape[area, subarea, sampletype, PFAS][1]:
                        D_monthXkd_PFAS_shape[area, subarea, sampletype, PFAS] = [i,j]
                except KeyError:
                    D_monthXkd_PFAS_shape[area, subarea, sampletype, PFAS] = [i,j]
        for sample_PFAS in D_monthXkd_PFAS_shape:
            a, b = D_monthXkd_PFAS_shape[sample_PFAS]
            D_monthXkd_PFAS[sample_PFAS] = np.zeros((a+1, b+1))
    with open(filename, mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        Head = True
        for line in data:
            if Head:
                Head = False
            else:
                index, area, subarea, sampletype, PFAS, i, j, pred = line
                i = int(i)
                j = int(j)
                pred = float(pred) # predicted logkd
                #print(np.shape(D_monthXkd_PFAS[area, subarea, sampletype, PFAS]), i,j)
                D_monthXkd_PFAS[area, subarea, sampletype, PFAS][i,j] = pred
    del(D_monthXkd_PFAS_shape)
    #print(D_monthXkd_PFAS)
    return D_monthXkd_PFAS
    
"""_____________________________________________________________________________________________________________________"""
'''5.1 get dictionary for conc_in_particleform { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc] }'''
def index_PFAS(D_head_ind, PFAS):
    for ind in D_head_ind:
        if D_head_ind[ind] == PFAS:
            return ind-13
        else:
            pass
def strip_nan(L):
    L2 = []
    for conc in L:
        if conc == conc:
            L2.append(conc)
        else:
            pass
    return L2
def get_D_particle_conc(D_monthXkd_PFAS, D_raw_xyz, D_head_ind, D_logSS):
    '''
    Parameters
    ----------
    D_monthXkd_PFAS : dict
        { area, subarea, sample type, PFAS: 2Darray[logkd]shape(12Xsims_sampletype/subarea)}.
    D_raw_xyz : dict
        {  area, subarea, sampletype: [T_water,sd] , [POCs], [PFASs conc arr: shape (#_of_PFAS, Counts)] }

    Returns
    -------
    D_ptcl_conc: dict
        { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc, ... ] }
    '''
    D_ptcl_conc = dict()
    for area, subarea, sampletype, PFAS in D_monthXkd_PFAS:
        N_month, N_sims  = np.shape(D_monthXkd_PFAS[area, subarea, sampletype, PFAS])
        ind = index_PFAS(D_head_ind, PFAS)
        
        arr_ptcl_conc = np.zeros((N_month, N_sims))
        
        L_countsmany_conc = [conc for conc in D_raw_xyz[area, subarea, sampletype][2][ind]]
        L_countsmany_conc = strip_nan(L_countsmany_conc)
        L_sims2Darr_conc = []
        for month in range(N_month):
            L_sims2Darr_conc.append(random.choices(L_countsmany_conc, k=N_sims))
        sims2Darr_conc = np.array(L_sims2Darr_conc)
        # prepare conc for each PFAS (N_simsX12 many)
        
        #SS_mu, SS_sd = D_SS[area]
        logSS_mu, logSS_sd = D_logSS[area]
        for month in range(N_month):
            for sim in range(N_sims):
                '''
                SS = 0
                while SS <= 0:
                    SS = random.normalvariate(SS_mu, SS_sd)
                '''
                logSS =  random.normalvariate(logSS_mu, logSS_sd)
                SS = 10**logSS
                #print( area, PFAS, round(D_monthXkd_PFAS[area, subarea, sampletype, PFAS][month, sim],2),  round(SS,0),  round(sims2Darr_conc[month, sim],1) )
                #prepare SS for every PFAS(N_simsX12 many)
                arr_ptcl_conc[month, sim] = 10**D_monthXkd_PFAS[area, subarea, sampletype, PFAS][month, sim] * SS * sims2Darr_conc[month, sim]* 10**-6
        
        D_ptcl_conc[area, subarea, sampletype, PFAS] = arr_ptcl_conc
    return D_ptcl_conc
'''5.2 get dictionary for conc_in_waterform { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc] }'''
def get_D_water_conc(D_monthXkd_PFAS, D_raw_xyz, D_head_ind):
    '''
    Parameters
    ----------
    D_raw_xyz : dict
        {  area, subarea, sampletype: [T_water,sd] , [POCs], [PFASs conc arr: shape (#_of_PFAS, Counts)] }
    D_monthXkd_PFAS : dict
        { area, subarea, sample type, PFAS: 2Darray[logkd]shape(12Xsims_sampletype/subarea)}.

    Returns
    -------
    D_solu_conc: dict
        { subarea, sample type, PFAS: 2Darray(12, No_sims)[PFAS_conc, PFAS_conc, ... ] }
    '''
    D_solu_conc = dict()
    for area, subarea, sampletype, PFAS in D_monthXkd_PFAS:
        N_month, N_sims  = np.shape(D_monthXkd_PFAS[area, subarea, sampletype, PFAS])
        ind = index_PFAS(D_head_ind, PFAS)
        
        arr_solu_conc = np.zeros((N_month, N_sims))
        
        L_countsmany_conc = [conc for conc in D_raw_xyz[area, subarea, sampletype][2][ind]]
        L_countsmany_conc = strip_nan(L_countsmany_conc)
        L_sims2Darr_conc = []
        for month in range(N_month):
            L_sims2Darr_conc.append(random.choices(L_countsmany_conc, k=N_sims))
        sims2Darr_conc = np.array(L_sims2Darr_conc)
        # prepare conc for each PFAS (N_simsX12 many)
        
        D_solu_conc[area, subarea, sampletype, PFAS] = sims2Darr_conc
    return D_solu_conc
    

"""_____________________________________________________________________________________________________________________"""
'''6. save dictionary into file:  area| subare| sampletype| PFAS1_Jan | PFAS1_Feb | ... | PFAS1_Dec | PFAS2_Jan | ...'''
def takesecond(l):
    return l[1]

def save_D_particle_PFAS_conc(D_ptcl_conc, D_head_ind, filename='PFAS_in_particle_conc'):
    '''conc in 1E-18 level'''
    L_PFASXmonth_head = []
    L_PFAS = []
    for ind in D_head_ind:
        if ind >= 13 and ind <26:
            L_PFAS.append(D_head_ind[ind])
        else:
            pass
    L_PFAS.sort()
    for PFAS in L_PFAS:
        L_PFASXmonth_head = L_PFASXmonth_head + [PFAS + '^' + str(i) for i in range(12)] # Dec = 0, Jan = 1, ...
    
    headline = ['area','subarea','sampletype']+L_PFASXmonth_head
    
    D_med = dict()
    for area, subarea, sampletype, PFAS in D_ptcl_conc:
        arr_PFAS_conc = D_ptcl_conc[area, subarea, sampletype, PFAS]        
        try:
            D_med[area, subarea, sampletype].append([arr_PFAS_conc ,PFAS])
        except KeyError:
            D_med[area, subarea, sampletype] = [[arr_PFAS_conc ,PFAS]]
    for area, subarea, sampletype in D_med:
        # check if there are some PFASs not being detected
        L_PFAS_subtype = [item[1] for item in D_med[area, subarea, sampletype]]
        if len(L_PFAS) > len(L_PFAS_subtype):
            for PFAS in L_PFAS:
                if PFAS not in L_PFAS_subtype:
                    nan_ele = [np.nan*np.ones(np.shape(D_med[area, subarea, sampletype][0][0])), PFAS]
                    D_med[area, subarea, sampletype].append(nan_ele)
                else:
                    pass
            D_med[area, subarea, sampletype].sort(key=takesecond)
        else:
            D_med[area, subarea, sampletype].sort(key=takesecond)
        D_med[area, subarea, sampletype] = np.transpose( np.concatenate([item[0] for item in D_med[area, subarea, sampletype]], axis=0) )
            
    with open(filename+'.csv', mode='w', newline='') as file:
        data = csv.writer(file)
        data.writerow(headline)
        for area, subarea, sampletype in D_med:
            for row in D_med[area, subarea, sampletype]:
                line = [area, subarea, sampletype]+[conc for conc in row]
                data.writerow(line)
    del(D_med)
    return
"""___________________________prediction of logkd__________________________________________________________________________________________"""
def read_xyz(filepath, filename):
    labelpart = []
    arr_predict = []
    with open( filepath+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        line1 = True
        ind = 0
        for line in data:
            if line1:
                line1 = False
                headline = ['']+[line[i] for i in range(6)]
                labelpart.append(headline)
            else:
                # combine index, label
                ind = ind + 1
                labelpart.append([ind]+[line[i] for i in range(6)])
                # combine arr for prediction
                arr_predict.append([ float(line[i+6]) for i in range(5) ])
    arr2predict = np.array(arr_predict)
    return labelpart, arr2predict

def read_modelset(filepath, filename):
    dataset = []
    with open(filepath + filename, mode = 'r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            #log Kd|	T|	log Kow4|	TOC|	remote|	logTOC|
            if head:
                head = False
            else:
                dataset.append([float(item) for item in line])
    return np.transpose(np.array(dataset))

def get_xgbmodel(path, modelname):
    xgbrf_model = xgb.Booster()
    xgbrf_model.load_model(path + modelname)
    return xgbrf_model

def predict(model, arr):
    D_arr = xgb.DMatrix(arr)
    return model.predict(D_arr)

def save_predict(filepath,filename,labelpart,predicted):
    with open(filepath + filename, mode = 'w', newline='') as file:
        data = csv.writer(file)
        head = True
        for item in labelpart:
            if head:
                head = False
                line = item + ['logKd']
                data.writerow(line)
            else:
                ind = item[0]-1
                line = item + [ predicted[ind] ]
                data.writerow(line)
    return

"""_____________________________________________________________________________________________________________________"""
'''main'''
def main1(file_name, simulation_per_area = 100, mag_of_normal = 10, path = ''):
    chemlogkow_filename = path + 'logKow.xlsx'
    PFAS_filename = path + 'PFAS_conc_locs_data'
    D_SS = {'West Canada and USA':[182.225, 156.144978705689], 'Arctic Canada': [96.5714285714286,68.3412804404841], 'Greenland':[881.180681818182,1456.65840998389], 'Arctic Europe':[91.2771929824561, 135.722388251984],'North Asia':[91.2771929824561, 135.722388251984], 'Central Europe':[355.5, 158.511566349799], 'South and Central Asia':[485.792857142857, 348.35338296105], 'Antarctic and Subantarctic ice sheet':[72.555, 106.902201840436]}
    D_logSS = {'West Canada and USA':[1.959833307, 0.670021258917696], 'Arctic Canada': [1.91005449514286,0.249937708818148], 'Greenland':[2.48036737303977,0.851292712912363], 'Arctic Europe':[1.45866884542105, 0.797334354872893],'North Asia':[1.45866884542105, 0.797334354872893], 'Central Europe':[2.49593689983333, 0.258785008819775], 'South and Central Asia':[2.59879782971429, 0.28688964499567], 'Antarctic and Subantarctic ice sheet':[1.48529546283333, 0.575151204423112]}
    D_chemkow = read_logkow(chemlogkow_filename)
    D_all_data, D_area_subsize, D_head_ind = read_PFAS_data(PFAS_filename)
    
    D_sims_weights = get_dict_sims(D_all_data, D_area_subsize, N = simulation_per_area)
    D_raw_xyz = get_dict_raw_xyz(D_all_data, mag = mag_of_normal)
    D_dis_params = get_distruibution(D_raw_xyz)
    D_sims_envi = get_envi_samples(D_dis_params, D_sims_weights)
    del(D_sims_weights)
    D_xyz_monthXPFAS = get_xyz(D_sims_envi, D_dis_params, D_head_ind, D_chemkow)
    del(D_dis_params)
    del(D_sims_envi)
    save_D_xyz_monthXPFAS(D_xyz_monthXPFAS, path + file_name)
    return
    
def main2(file_name, simulation_per_area = 100, mag_of_normal = 10 ,path=''):
    chemlogkow_filename = path + 'logKow.xlsx'
    PFAS_filename = path + 'PFAS_conc_locs_data'
    D_SS = {'West Canada and USA':[182.225, 156.144978705689], 'Arctic Canada': [96.5714285714286,68.3412804404841], 'Greenland':[881.180681818182,1456.65840998389], 'Arctic Europe':[91.2771929824561, 135.722388251984],'North Asia':[91.2771929824561, 135.722388251984], 'Central Europe':[355.5, 158.511566349799], 'South and Central Asia':[485.792857142857, 348.35338296105], 'Antarctic and Subantarctic ice sheet':[72.555, 106.902201840436]}
    D_logSS = {'West Canada and USA':[1.959833307, 0.670021258917696], 'Arctic Canada': [1.91005449514286,0.249937708818148], 'Greenland':[2.48036737303977,0.851292712912363], 'Arctic Europe':[1.45866884542105, 0.797334354872893],'North Asia':[1.45866884542105, 0.797334354872893], 'Central Europe':[2.49593689983333, 0.258785008819775], 'South and Central Asia':[2.59879782971429, 0.28688964499567], 'Antarctic and Subantarctic ice sheet':[1.48529546283333, 0.575151204423112]}
    D_all_data, D_area_subsize, D_head_ind = read_PFAS_data(PFAS_filename)
    D_raw_xyz = get_dict_raw_xyz(D_all_data, mag = mag_of_normal)
    D_monthXkd_PFAS = get_kd_by_xyz(path + file_name)
    D_solu_conc = get_D_water_conc(D_monthXkd_PFAS, D_raw_xyz, D_head_ind)
    D_ptcl_conc = get_D_particle_conc(D_monthXkd_PFAS, D_raw_xyz, D_head_ind, D_logSS)
    del(D_monthXkd_PFAS)
    del(D_raw_xyz)
    save_D_particle_PFAS_conc(D_ptcl_conc, D_head_ind, filename=path +'PFAS_in_particle_conc')
    save_D_particle_PFAS_conc(D_solu_conc, D_head_ind, filename=path +'PFAS_in_water_conc')
    del(D_ptcl_conc)
    
def main3(modelpath = 'G:/glacier flux simulation/', path = ''):
    labelpart, arr2predict = read_xyz(path, 'xyz_sims.csv')
    model = get_xgbmodel(modelpath, modelname = 'xgb_best.json') #load model in .json form
    predicted = predict(model, arr2predict)
    save_predict(path,'xyz_sims_logkd_xgb.csv',labelpart,predicted)
    return
    
"""_____________________________________________________________________________________________________________________"""
#main1('xyz_sims.csv')
#main2('xyz_sims_logkd_xgb.csv')
#main3(modelpath = 'F:/zyq/logkd model/', path = 'F:/zyq/globle warmming prediction/0712 sims/2015/SSP126/')
